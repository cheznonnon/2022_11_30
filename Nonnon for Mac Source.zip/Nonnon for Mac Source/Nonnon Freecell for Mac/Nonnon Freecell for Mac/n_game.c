// Project Nonnon
// copyright (c) nonnon all rights reserved
// License : GPL http://www.gnu.org/copyleft/gpl.html


// Template File


// [!] : Usage
//
//	1 : replace your NSView (Custom View) to NonnonGame
//	2 : IB : right pane : "Custom Class", "Class", set "NonnonGame"
//	3 : modify behavior


// [!] : trouble shooter
//
//	[ drawRect is not called at redraw ]
//
//		a : call [_n_game display];
//		b : see your @property and connect(DnD) to UI on the Xib canvas
//		c : layer may cause




#ifndef _H_NONNON_MAC_NONNON_GAME
#define _H_NONNON_MAC_NONNON_GAME




#import <Cocoa/Cocoa.h>


#include "../../nonnon/mac/_mac.c"
#include "../../nonnon/mac/image.c"
#include "../../nonnon/mac/sound.c"
#include "../../nonnon/mac/window.c"




@interface NonnonGame : NSView <AVAudioPlayerDelegate>
@end




#include "nfreecell.c"




@interface NonnonGame ()

- (void) n_timer_method;

@end

/*
static CVReturn
n_displaylink_callback
(
	      CVDisplayLinkRef  displayLink,
	const CVTimeStamp      *now,
	const CVTimeStamp      *outputTime,
	      CVOptionFlags     flagsIn,
	      CVOptionFlags    *flagsOut,
	      void*             displayLinkContext
)
{
//NSLog( @"!" );

	NonnonGame *n_game = (__bridge NonnonGame*) displayLinkContext;

	dispatch_sync(
		dispatch_get_main_queue(),
		^{
			[n_game n_timer_method];
		}
	);


	return kCVReturnSuccess;
}
*/


@implementation NonnonGame {

	n_freecell freecell;
	    NSRect freecell_rect;

	CVDisplayLinkRef displayLink;

}


- (instancetype)initWithCoder:(NSCoder *)coder
{
//NSLog( @"initWithCoder" );

	self = [super initWithCoder:coder];
	if ( self )
	{

		n_freecell_zero( &freecell );
		n_freecell_init( &freecell );
//NSLog( @"%d %d", freecell.sx, freecell.sy );

		n_freecell_loop( &freecell );

		freecell.self = self;


		// [!] : faster than CVDisplayLink

		n_mac_timer_init( self, @selector( n_timer_method ), 1 );

/*
		CVDisplayLinkCreateWithActiveCGDisplays( &displayLink );
		CVDisplayLinkSetOutputCallback
		(
			displayLink,
			&n_displaylink_callback,
			(__bridge void*) self
		);
		CVDisplayLinkStart( displayLink );
*/
	}


	return self;
}


- (void) n_mac_game_canvas_resize:(NSWindow*)window width:(n_type_gfx)sx height:(n_type_gfx)sy
{
//NSLog( @"!" );

	if ( sx == -1 ) { sx = freecell.sx; }
	if ( sy == -1 ) { sy = freecell.sy; }
//NSLog( @"%d %d", sx, sy );

	NSSize size = NSMakeSize( sx,sy );

	[window setContentMinSize:size];
	//[window setContentMaxSize:size];

	freecell_rect = NSMakeRect( 0,0,sx,sy );
	[self setFrame:freecell_rect];

	[window setContentSize:size];

	freecell.refresh = TRUE;

	[window display];

}

- (void) n_on_resize:(NSWindow*) window
{
//NSLog( @"n_on_resize" );

	n_freecell *p = &freecell;


	//if ( p->is_init == n_posix_false ) { return; }


	NSRect content = [window contentRectForFrameRect:window.frame];
	
	CGFloat sx = NSWidth ( content );
	CGFloat sy = NSHeight( content );

	freecell_rect = NSMakeRect( 0,0,sx,sy );
	[self setFrame:freecell_rect];

	p->cardgen.csx = p->sx = sx;
	p->cardgen.csy = p->sy = sy;


	n_bmp_new( &p->canvas, sx, sy );
	n_freecell_flush_background( p );

	if ( p->animation_onoff )
	{
		n_freecell_animation_go( p, p->animation_index_f, p->animation_index_t );
	}

	n_freecell_reposition( p );
	n_freecell_redraw( p );

	freecell.refresh = TRUE;

	n_freecell_loop( p );


	[window display];
} 

/*
- (BOOL) isFlipped
{
	return YES;
}
*/

- (void) n_timer_method
{

//NSLog( @"%f", CACurrentMediaTime() );

//static u32 tick_prv = 0;

	static u32 timer = 0;
	if ( n_game_timer( &timer, 12 ) )
	{
		n_freecell_loop( &freecell );
	}


	if ( freecell.refresh )
	{
//n_mac_debug_count();
		freecell.refresh = FALSE;

		[self display];
	}

//u32 tick_cur = n_posix_tickcount();

//NSLog( @"%d", (int) tick_cur - tick_prv );

//tick_prv = tick_cur;

}


- (void) drawRect:(NSRect) rect
{
//NSLog( @"drawRect" );

	n_mac_image_nbmp_direct_draw( &freecell.canvas, &freecell_rect, n_posix_false );

}


- (void) mouseUp:(NSEvent*) theEvent
{
//NSLog( @"mouseUp" );

	n_game_chara_cursor_position = NSMakePoint( -freecell.sx, -freecell.sy );

}

- (void) mouseDown:(NSEvent*) theEvent
{
//NSLog(@"mouseDown");

	n_game_chara_cursor_position = n_mac_image_position_flip( &freecell.canvas, [theEvent locationInWindow] );

	if ( [theEvent clickCount] == 2 )
	{
		freecell.doubleclick = n_posix_true;
		n_freecell_loop( &freecell );
		freecell.doubleclick = n_posix_false;
	}

}

- (void) mouseDragged:(NSEvent*) theEvent
{
//NSLog(@"mouseDragged");

	freecell.refresh = TRUE;

	n_game_chara_cursor_position = n_mac_image_position_flip( &freecell.canvas, [theEvent locationInWindow] );
//NSLog( @"%f %f", n_mac_is_input_cursor.x, n_mac_is_input_cursor.y );

}


- (void) n_newgame
{
	n_freecell_newgame( &freecell );
	freecell.refresh = TRUE;
}

- (void) n_replay
{
	n_freecell_replay( &freecell );
	freecell.refresh = TRUE;
}


@end


#endif // _H_NONNON_MAC_NONNON_GAME


