// Project Nonnon
// copyright (c) nonnon all rights reserved
// License : GPL http://www.gnu.org/copyleft/gpl.html


// Template File




#ifndef _H_NONNON_MAC_NONNON_BUTTON
#define _H_NONNON_MAC_NONNON_BUTTON




#import <Cocoa/Cocoa.h>


#include "../neutral/posix.c"

#include "../neutral/bmp/ui/roundframe.c"

#include "../neutral/bmp/all.c"
#include "../neutral/bmp/fade.c"

#include "image.c"




#define N_MAC_BUTTON_FADE_TYPE_HOT    ( 0 )
#define N_MAC_BUTTON_FADE_TYPE_PRESS  ( 1 )
#define N_MAC_BUTTON_FADE_TYPE_NORMAL ( 2 )




typedef struct {

	// [!] : internal

	double       scale;

	n_bmp_fade   fade;
	n_posix_bool fade_onoff;
	u32          fade_timer_id;
	int          fade_type;

	n_posix_bool active_onoff;
	n_posix_bool   sink_onoff;
	n_posix_bool    hot_onoff;
	n_posix_bool   hide_onoff;
	n_posix_bool  press_onoff;
	n_posix_bool   prev_onoff;


	// [!] : option : you can set these directly

	n_bmp         icon;

	n_posix_bool  show_border;
	BOOL          direct_click_onoff;

} n_mac_button;


#define n_mac_button_zero( p ) n_memory_zero( p, sizeof( n_mac_button ) )




void
n_mac_button_system_themed( n_bmp *bmp )
{

	NSColor *nscolor_accent = [NSColor controlAccentColor];

	u32 base = n_mac_nscolor2argb( nscolor_accent );
	u32 face = n_bmp_black;
	u32 lite = n_bmp_white;
	u32 pink = n_bmp_hue_wheel_tweak_pixel( base, 64 );

	n_bmp_flush_replacer( bmp, n_bmp_rgb( 200,240,255 ), n_bmp_blend_pixel( base, lite, 0.75 ) );
	n_bmp_flush_replacer( bmp, n_bmp_rgb( 100,220,255 ), n_bmp_blend_pixel( base, lite, 0.50 ) );
	n_bmp_flush_replacer( bmp, n_bmp_rgb(   0,200,255 ), n_bmp_blend_pixel( base, face, 0.00 ) );
	n_bmp_flush_replacer( bmp, n_bmp_rgb(   0,150,200 ), n_bmp_blend_pixel( base, face, 0.25 ) );
	n_bmp_flush_replacer( bmp, n_bmp_rgb(   0,100,150 ), n_bmp_blend_pixel( base, face, 0.50 ) );
	n_bmp_flush_replacer( bmp, n_bmp_rgb(   0, 50,100 ), n_bmp_blend_pixel( base, face, 0.75 ) );

	n_bmp_flush_replacer( bmp, n_bmp_rgb( 255,  0,150 ), n_bmp_blend_pixel( pink, face, 0.00 ) );
	n_bmp_flush_replacer( bmp, n_bmp_rgb( 200,  0,100 ), n_bmp_blend_pixel( pink, face, 0.25 ) );
	n_bmp_flush_replacer( bmp, n_bmp_rgb( 150,  0, 50 ), n_bmp_blend_pixel( pink, face, 0.50 ) );


	return;
}

void
n_mac_button_box( n_bmp *bmp, NSRect rect, NSColor *color )
{

	n_type_gfx x,y,sx,sy; n_mac_rect_expand_size( rect, &x, &y, &sx, &sy );

	u32 argb = n_mac_nscolor2argb( color );

	n_bmp_box( bmp, x,y,sx,sy, argb );


	return;
}

n_posix_bool
n_mac_button_is_enabled( n_mac_button *p )
{
	return p->active_onoff;
}

void
n_mac_button_fade_go( n_mac_button *p )
{

	u32 color;
	if ( p->fade.color_fg == n_bmp_white )
	{
		color = n_bmp_black;
	} else {
		color = n_bmp_white;
	}

	p->fade.stop = n_posix_true;

	n_bmp_fade_go( &p->fade, color );


	return;
}

void
n_mac_button_draw( n_mac_button *p, NSRect rect )
{

	BOOL prv_n_memory_free_onoff = n_memory_free_onoff;
	n_memory_free_onoff = TRUE;


	n_type_gfx sx,sy; n_mac_rect_expand_size( rect, NULL, NULL, &sx, &sy );
//NSLog( @"Canvas Size %d", sx );


	n_bmp bmp_canvas; n_bmp_zero( &bmp_canvas ); n_bmp_1st_fast( &bmp_canvas, sx,sy );
	n_bmp_flush( &bmp_canvas, n_mac_nscolor2argb( [NSColor clearColor] ) );


	u32 color_bg;

	if ( n_posix_false == n_mac_button_is_enabled( p ) )
	{
		u32 bg = n_mac_nscolor2argb( [NSColor windowBackgroundColor] );
		u32 fg = n_mac_nscolor2argb( [NSColor        lightGrayColor] );
		color_bg = n_bmp_blend_pixel( bg, fg, 0.33 );
	} else
	if ( p->press_onoff )
	{
		color_bg = n_mac_nscolor2argb( [NSColor lightGrayColor] );
	} else
	if ( p->fade.stop == n_posix_false )
	{
		u32 color_f, color_t;
		if ( p->fade_type == N_MAC_BUTTON_FADE_TYPE_HOT )
		{
			if ( p->hot_onoff )
			{
//NSLog( @"normal to hot" );
				color_f = n_bmp_white_invisible;
				color_t = n_mac_nscolor2argb( [NSColor controlLightHighlightColor] );
			} else {
//NSLog( @"hot to normal" );
				color_t = n_bmp_white_invisible;
				color_f = n_mac_nscolor2argb( [NSColor controlLightHighlightColor] );
			}
		} else
		if ( p->fade_type == N_MAC_BUTTON_FADE_TYPE_PRESS )
		{
			if ( p->press_onoff )
			{
				color_f = n_mac_nscolor2argb( [NSColor controlLightHighlightColor] );
				color_t = n_mac_nscolor2argb( [NSColor             lightGrayColor] );
			} else {
				color_t = n_mac_nscolor2argb( [NSColor controlLightHighlightColor] );
				color_f = n_mac_nscolor2argb( [NSColor             lightGrayColor] );
			}
		} else
		//if ( p->fade_type == N_MAC_BUTTON_FADE_TYPE_NORMAL )
		{
			color_f = n_mac_nscolor2argb( [NSColor        lightGrayColor] );
			color_t = n_mac_nscolor2argb( [NSColor windowBackgroundColor] );
		}

		color_bg = n_bmp_blend_pixel( color_f, color_t, (double) p->fade.percent * 0.01 );
	} else {
		if ( p->hot_onoff )
		{
			color_bg = n_mac_nscolor2argb( [NSColor controlLightHighlightColor] );
		} else {
			color_bg = n_mac_nscolor2argb( [NSColor                 clearColor] );
		}
	}

	u32 color_border;
	if ( p->show_border )
	{
		if ( n_mac_is_darkmode() )
		{
			color_border = n_mac_nscolor2argb( [NSColor      grayColor] );
		} else {
			color_border = n_mac_nscolor2argb( [NSColor lightGrayColor] );
		}
	} else {
		color_border = n_mac_nscolor2argb( [NSColor clearColor] );
	}

	if ( p->show_border )
	{
		n_bmp_squircle( &bmp_canvas, 1,1,sx,sy, color_border, 6.66 );

		n_type_gfx  ox = 1;
		n_type_gfx  oy = 1;
		n_type_gfx osx = ox * 2;
		n_type_gfx osy = oy * 2;

		n_bmp_squircle( &bmp_canvas, 1+ox,1+oy,sx-osx,sy-osy, color_bg, 6.66 );
	} else {
		n_bmp_squircle( &bmp_canvas, 1,1,sx,sy, color_bg, 6.66 );
	}


	n_type_gfx scale       = 1;
	n_type_gfx offset_sink = scale;


	{
		n_type_gfx ico_sx = 32;
		n_type_gfx ico_sy = 32;


		n_type_gfx tx = ( sx - ico_sx ) / 2;
		n_type_gfx ty = ( sy - ico_sy ) / 2;

		//n_bmp bmp_icon; n_bmp_zero( &bmp_icon );
		//n_mac_image_rc_load_bmp( @"neko", &bmp_icon );

		if ( n_mac_button_is_enabled( p ) )
		{
			if ( p->sink_onoff )
			{
				n_type_gfx o = offset_sink;

				tx += o;
				ty += o;
			}

			n_bmp_transcopy( &p->icon, &bmp_canvas, 0,0,ico_sx,ico_sy, tx,ty );
		} else {
			n_bmp grayed; n_bmp_carboncopy( &p->icon, &grayed );
			n_bmp_flush_grayscale( &grayed );

			n_bmp_blendcopy( &grayed, &bmp_canvas, 0,0,ico_sx,ico_sy, tx,ty, 0.2 );

			n_bmp_free_fast( &grayed );
		}

		//n_bmp_free_fast( &bmp_icon );

	}


	n_bmp_mac( &bmp_canvas );
	n_mac_image_nbmp_direct_draw( &bmp_canvas, &rect, YES );


	n_bmp_free_fast( &bmp_canvas );


	n_memory_free_onoff = prv_n_memory_free_onoff;


	return;
}




@interface NonnonButton : NSView

@property (nonatomic,assign) id delegate;
@property (nonatomic,assign) id delegate_right;

@end


@implementation NonnonButton {

	n_mac_button  button;
	NSTimer      *nstimer;

}


@synthesize delegate;
@synthesize delegate_right;




- (instancetype)initWithCoder:(NSCoder *)coder
{
//NSLog( @"initWithCoder" );

	self = [super initWithCoder:coder];
	if ( self )
	{
		n_mac_button_zero( &button );
		
		n_bmp_fade_init( &button.fade, n_bmp_black );

		NSTrackingArea* trackingArea = [[NSTrackingArea alloc]
			initWithRect:[self bounds]
			     options:NSTrackingMouseEnteredAndExited | NSTrackingActiveAlways
			       owner:self
			    userInfo:nil
		];
		[self addTrackingArea:trackingArea];
	}
	
	return self;
}




- (BOOL) isFlipped
{
	return YES;
}




- (void) n_timer_method
{

	n_mac_button *p = &button;

	n_bmp_fade_engine( &p->fade, n_posix_true );
//NSLog( @"%d", p->fade.percent );

	[self display];

	if ( p->fade.percent == 100 )
	{
		n_mac_timer_exit( nstimer );
	}

}




- (void) n_icon_set:(n_bmp*) icon;
{

	n_mac_button *p = &button;

	p->icon = (*icon);

}

- (n_posix_bool) n_is_enabled
{

	n_mac_button *p = &button;

	return p->active_onoff;

}

- (void) n_enable:(n_posix_bool)onoff
{

	n_mac_button *p = &button;

	p->active_onoff = onoff;

}

- (n_posix_bool) n_is_pressed
{

	n_mac_button *p = &button;

	return p->press_onoff;

}

- (void) n_press:(n_posix_bool)onoff
{

	n_mac_button *p = &button;

	p->prev_onoff = p->press_onoff = onoff;

}

- (void) n_border:(n_posix_bool)onoff
{

	n_mac_button *p = &button;

	p->show_border = onoff;

}

- (void) n_direct_click:(n_posix_bool)onoff
{

	n_mac_button *p = &button;

	p->direct_click_onoff = onoff;

}




- (BOOL) acceptsFirstMouse:(NSEvent *)event
{

	n_mac_button *p = &button;

	return p->direct_click_onoff;
}




- (void)drawRect:(NSRect)rect
{
//NSLog( @"drawRect" );

	n_mac_button *p = &button;


	if ( p->hide_onoff ) { return; }


	n_mac_button_draw( p, rect );

}




- (void) mouseDown:(NSEvent*) theEvent
{
//NSLog(@"mouseDown");

	n_mac_button *p = &button;


	if ( p->hide_onoff ) { return; }

	if ( n_posix_false == n_mac_button_is_enabled( p ) ) { return; }


	p-> prev_onoff = p->press_onoff;
	p->  hot_onoff = n_posix_false;
	p-> sink_onoff = n_posix_true;
	p->press_onoff = n_posix_true;

	p->fade_type = 	N_MAC_BUTTON_FADE_TYPE_PRESS;
	n_mac_button_fade_go( p );
	nstimer = n_mac_timer_init( self, @selector( n_timer_method ), 33 );


	[self display];

}

- (void) mouseUp:(NSEvent*) theEvent
{
//NSLog(@"mouseUp");

	n_mac_button *p = &button;


	if ( p->hide_onoff ) { return; }

	if ( n_posix_false == n_mac_button_is_enabled( p ) ) { return; }


	if ( p->press_onoff )
	{
		p->  hot_onoff = n_posix_true;
		p-> sink_onoff = n_posix_false;
		p->press_onoff = p->prev_onoff;

		p->fade_type = 	N_MAC_BUTTON_FADE_TYPE_PRESS;
		n_mac_button_fade_go( p );
		nstimer = n_mac_timer_init( self, @selector( n_timer_method ), 33 );

		[self display];

		[delegate mouseUp:theEvent];
	}

}




- (void) rightMouseUp:(NSEvent*) theEvent
{

	[delegate_right rightMouseUp:theEvent];

}




-(void)mouseEntered:(NSEvent *)theEvent {
//NSLog(@"mouseEntered");

	n_mac_button *p = &button;

	if ( p->hide_onoff ) { return; }

	if ( n_posix_false == n_mac_button_is_enabled( p ) )
	{
		p->hot_onoff = FALSE;
		[self display];
	} else
	if ( p->hot_onoff )
	{
		//
	} else {
		p->hot_onoff = TRUE;

		p->fade_type = 	N_MAC_BUTTON_FADE_TYPE_HOT;
		n_mac_button_fade_go( p );
		nstimer = n_mac_timer_init( self, @selector( n_timer_method ), 33 );
	}

}

-(void)mouseExited:(NSEvent *)theEvent {
//NSLog(@"mouseExited");

	n_mac_button *p = &button;

	if ( p->hide_onoff ) { return; }

	if ( n_posix_false == n_mac_button_is_enabled( p ) )
	{
		p->hot_onoff = FALSE;
	} else
	if ( p->hot_onoff )
	{
		p->hot_onoff = FALSE;

		p->fade_type = 	N_MAC_BUTTON_FADE_TYPE_HOT;
		n_mac_button_fade_go( p );
		nstimer = n_mac_timer_init( self, @selector( n_timer_method ), 33 );
	} else
	if ( p->press_onoff )
	{
		p->press_onoff = p->prev_onoff;

		p->fade_type = 	N_MAC_BUTTON_FADE_TYPE_NORMAL;
		n_mac_button_fade_go( p );
		nstimer = n_mac_timer_init( self, @selector( n_timer_method ), 33 );
	}

	p->sink_onoff = FALSE;

	[self display];

}




@end




#endif // _H_NONNON_MAC_NONNON_BUTTON


