// CatPad
// copyright (c) nonnon all rights reserved
// License : GPL http://www.gnu.org/copyleft/gpl.html


// Partial File




@implementation NonnonTxtbox (NonnonTxtboxDragAndDrop)


-(BOOL) n_txtbox_open:(NSString*)nsstring
{

	n_posix_char *str        = n_mac_nsstring2str( nsstring );

	n_txt_load_utf8_error_dialog_onoff = n_posix_true;
	n_txt_load_utf8( n_txt_data, str );
	n_txt_load_utf8_error_dialog_onoff = n_posix_false;

//NSLog( @"Unicode %d : Newline %d", n_txt->unicode, n_txt->newline );

	n_path = nsstring;

	[self NonnonTxtboxReset];
	[self NonnonTxtboxUndo:N_TXTBOX_UNDO_RESET];

	n_edited = FALSE;
	if ( delegate_option & N_MAC_TXTBOX_DELEGATE_EDITED )
	{
		[self.delegate NonnonTxtbox_delegate_edited:self onoff:n_edited];
	}

	[self display];


	n_string_free( str );


	[self.delegate NonnonTxtbox_delegate_dropped];


	return YES;
}




-(NSDragOperation) draggingEntered:( id <NSDraggingInfo> ) sender
{
//NSLog( @"draggingEntered" );

	// [!] : call when hovered

	return NSDragOperationCopy;
}

-(void) draggingExited:( id <NSDraggingInfo> )sender
{
//NSLog( @"draggingExited" );
}

-(BOOL) prepareForDragOperation:( id <NSDraggingInfo> )sender
{
//NSLog( @"prepareForDragOperation" );

	return YES;
}

-(BOOL) performDragOperation:( id <NSDraggingInfo> )sender
{
//NSLog( @"performDragOperation" );

	return YES;
}

-(void) concludeDragOperation:( id <NSDraggingInfo> )sender
{
//NSLog( @"concludeDragOperation" );

	if ( self.n_mode == N_MAC_TXTBOX_MODE_LISTBOX ) { return; }
	if ( self.n_mode == N_MAC_TXTBOX_MODE_FINDBOX ) { return; }
	if ( self.n_mode == N_MAC_TXTBOX_MODE_ONELINE ) { return; }

	//[self setStringValue:@""];

	NSPasteboard *pasteboard = [sender draggingPasteboard];
	NSString     *nsstring   = [[NSURL URLFromPasteboard:pasteboard] path];

	[self n_txtbox_open:nsstring];

}

-(NSDragOperation) draggingUpdated:( id <NSDraggingInfo> ) sender
{
//NSLog( @"draggingUpdated" );

	return NSDragOperationCopy;
}


@end

