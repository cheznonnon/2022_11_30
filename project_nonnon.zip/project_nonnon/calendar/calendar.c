// Nonnon Applet
// copyright (c) nonnon all rights reserved
// License : GPL http://www.gnu.org/copyleft/gpl.html




#ifndef N_APPS_NAME_CALENDAR

#include "../nonnon/project/define_unicode.c"

//#define N_MEMORY_DEBUG

#include "../nonnon/game/timegettime.c"

#endif // #ifndef N_APPS_NAME_CALENDAR




#include "../nonnon/win32/win.c"
#include "../nonnon/win32/win_calendar.c"
#include "../nonnon/win32/win_menu.c"
#include "../nonnon/win32/win_popup.c"
#include "../nonnon/win32/win_simplemenu.c"
#include "../nonnon/win32/win_systray.c"

#include "../nonnon/project/macro.c"




static u32 n_calendar_color_cache = 0;

void
n_calendar_color( HWND hwnd )
{

	if ( ( n_win_darkmode_onoff )||( n_win_color_is_highcontrast() ) )
	{

		n_calendar_color_cache = n_bmp_rgb( 111,111,111 );

	} else {
/*
		// [!] : this will be a color of wallpaper

		HDC hdc = GetWindowDC( hwnd );
		int m   = GetSystemMetrics( SM_CXSIZEFRAME );

		n_calendar_color_cache = n_bmp_colorref2argb( GetPixel( hdc, m,m ) );

		ReleaseDC( hwnd, hdc );
*/

		n_calendar_color_cache = n_win_dwm_windowcolor_arranged();

	}


	return;
}




#ifndef N_APPS_NAME_CALENDAR

#define N_APPS_OPTION_CALENDAR n_posix_literal( "-calendar" )

#endif // #ifndef N_APPS_NAME_CALENDAR


#define N_CALENDAR_APPNAME n_posix_literal( "Nonnon Calendar" )
#define N_CALENDAR_STICKY  n_posix_literal( "-sticky" )


#define N_CALENDAR_TIMER_MSEC   GetDoubleClickTime()
#define N_CALENDAR_EVENT_LAUNCH WM_LBUTTONUP




typedef struct {

	n_bool     sticky;

	UINT       timer_id_main;
	UINT       id_tray;

	UINT       timer_id_lnch;

	n_type_gfx csx,csy;
	int        taskbar;

	n_bool     border_onoff;

} n_calendar;


static n_calendar calendar;


#define n_calendar_zero( p ) n_memory_zero( p, sizeof( n_calendar ) )




void
n_calendar_systray_callback( n_bmp *b, n_bmp *m )
{

	n_bmp_flush_replacer( b, n_bmp_rgb(   0,200,255 ), n_win_darkmode_systemcolor_colorref2argb_ui( COLOR_HIGHLIGHT ) );
	n_bmp_flush_replacer( b, n_bmp_rgb( 222,222,222 ), n_win_darkmode_systemcolor_colorref2argb_ui( COLOR_BTNFACE   ) );
	n_bmp_flush_replacer( b, n_bmp_rgb( 111,111,111 ), n_win_darkmode_systemcolor_colorref2argb_ui( COLOR_BTNSHADOW ) );


	return;
}




// internal
void
n_calendar_automove( HWND hwnd )
{

	if ( calendar.sticky )
	{

		calendar.taskbar = n_win_popup_automove( hwnd, calendar.csx, calendar.csy );

	} else {

		calendar.taskbar = 0;


		n_type_gfx desktop_sx, desktop_sy;
		n_win_desktop_size( &desktop_sx, &desktop_sy );


		n_type_gfx x,y; n_win_cursor_position( &x, &y );

		x = n_posix_minmax( 0, desktop_sx - calendar.csx, x - ( calendar.csx / 2 ) );
		y = n_posix_minmax( 0, desktop_sy - calendar.csy, y                        );


		SetWindowPos( hwnd, NULL, x, y, 0,0, SWP_NOSIZE );

	}


	return;
}

n_posix_char*
n_calendar_startup_commandline( void )
{

	n_posix_char *exe = n_win_exepath_new();

#ifdef N_APPS_NAME_CALENDAR

	n_posix_char *ret = n_string_path_cat( exe, N_STRING_SPACE, N_APPS_OPTION_CALENDAR, N_STRING_SPACE, N_CALENDAR_STICKY, NULL );
	n_string_free( exe );

#else  // #ifndef N_APPS_NAME_CALENDAR

	n_posix_char *ret = exe;

#endif // #ifndef N_APPS_NAME_CALENDAR


	return ret;
}

// internal
void
n_calendar_border_size( n_type_gfx *sx, n_type_gfx *sy )
{
//n_posix_debug_literal(  "%d ", GetSystemMetrics( SM_CXSIZEFRAME ) );

	if ( sx != NULL ) { (*sx) = GetSystemMetrics( SM_CXSIZEFRAME ); }
	if ( sy != NULL ) { (*sy) = GetSystemMetrics( SM_CYSIZEFRAME ); }

#ifdef _WIN64

	if ( sx != NULL ) { (*sx) *= 2; }
	if ( sy != NULL ) { (*sy) *= 2; }

#endif // #ifdef _WIN64


	return;
}

void
n_calendar_resize( HWND hwnd, HWND hcal )
{

	n_type_gfx border_sx = 0;
	n_type_gfx border_sy = 0;

	if ( calendar.border_onoff )
	{
		n_calendar_border_size( &border_sx, &border_sy );
	}


	n_type_gfx desktop_sx, desktop_sy;
	n_win_desktop_size( &desktop_sx, &desktop_sy );

	n_type_gfx desktop = n_posix_min_n_type_gfx( desktop_sx, desktop_sy );


	n_type_gfx csx = n_posix_max_n_type_gfx( 200, (n_type_gfx) ( (n_type_real) desktop * 0.25 ) ) + ( border_sx * 2 );
	n_type_gfx csy = n_posix_max_n_type_gfx( 200, (n_type_gfx) ( (n_type_real) desktop * 0.25 ) ) + ( border_sy * 2 );

// [!] : for rc/calendar.multi.ico : this will be 256px
//size = 250;


	n_win_popup_automove( hwnd, csx,csy );

#ifdef _MSC_VER

	if ( n_sysinfo_version_10_or_later() ) { csx += 1; }

#endif // #ifdef _MSC_VER


	{
		n_type_gfx bx  = border_sx;
		n_type_gfx by  = border_sy;
		n_type_gfx bsx = csx - ( border_sx * 2 );
		n_type_gfx bsy = csy - ( border_sy * 2 );

		n_win_move_simple( hcal, bx,by,bsx,bsy, n_false );
	}


	// [!] : for n_calendar_automove()

	calendar.csx = csx;
	calendar.csy = csy;


	return;
}

// internal
void
n_calendar_option( void )
{

	n_posix_char *cmdline = n_win_commandline_new();


#ifdef N_APPS_NAME_CALENDAR

	// [Needed] : for Nonnon Apps

	n_string_commandline_option( N_APPS_OPTION_CALENDAR, cmdline );

#endif // #ifdef N_APPS_NAME_CALENDAR


	if ( n_string_is_empty( cmdline ) )
	{
		calendar.sticky = n_false;
	} else {
		calendar.sticky = n_true;
	}


	n_string_path_free( cmdline );


	return;
}

n_bool
n_calendar_animation_onoff( void )
{

	n_bool onoff = n_false;

	SystemParametersInfo( SPI_GETMENUANIMATION, 0, &onoff, 0 );

	return onoff;
}

void
n_calendar_animatewindow( HWND hwnd, n_bool show_onoff )
{

	int sw;

	if ( show_onoff )
	{
		sw = SW_NORMAL;
	} else {
		sw = SW_HIDE;
	}

	if (
		( n_false == n_calendar_animation_onoff() )
		||
		( n_sysinfo_version_95() )
		||
		( ( n_sysinfo_version_98() )&&( sw == SW_HIDE ) )
		||
		( ( n_sysinfo_version_me() )&&( sw == SW_HIDE ) )
	)
	{

		ShowWindowAsync( hwnd, sw );

		return;
	}


	int aw;

	if ( show_onoff )
	{
		aw = n_AW_SLIDE;

		if ( calendar.sticky )
		{
			if ( calendar.taskbar == ABE_TOP )
			{
				aw |= n_AW_VER_POSITIVE;
			} else
			if ( calendar.taskbar == ABE_BOTTOM )
			{
				aw |= n_AW_VER_NEGATIVE;
			} else
			if ( calendar.taskbar == ABE_LEFT )
			{
				aw |= n_AW_HOR_POSITIVE;
			} else
			if ( calendar.taskbar == ABE_RIGHT )
			{
				aw |= n_AW_HOR_NEGATIVE;
			}
		} else {
			aw |= n_AW_VER_POSITIVE;
		}
	} else {
		aw = n_AW_BLEND | n_AW_HIDE;
	}


	if ( n_win_dwm_aeroglass_is_on() )
	{

		ShowWindowAsync( hwnd, sw );

	} else {

		n_win_calendar_printclient_onoff = n_true;

		n_bool ret = n_win_animatewindow( hwnd, 0, aw );
		if ( ret ) { ShowWindowAsync( hwnd, sw ); }

		n_win_calendar_printclient_onoff = n_false;

	}


	return;
}

void
n_calendar_autostyle( HWND hwnd )
{

	// [x] : for AnimateWindow()

	if ( n_win_fluent_ui_onoff )
	{
		n_win_style_new( hwnd, WS_POPUP );
		n_win_exstyle_new( hwnd, WS_EX_TOOLWINDOW );

		n_win_style_dropshadow_onoff( hwnd, n_true );
	} else
	if (
		( n_calendar_animation_onoff() )
		&&
		( n_sysinfo_version_8_or_later() )
		&&
		( n_false == n_sysinfo_version_10_or_later() )
	)
	{
		calendar.border_onoff = n_true;

		n_win_style_new( hwnd, WS_POPUP );
		n_win_exstyle_new( hwnd, WS_EX_TOOLWINDOW );

		n_win_style_dropshadow_onoff( hwnd, n_true );
	} else {
		n_win_popup_autostyle( hwnd, NULL,NULL );
	}


	return;
}

LRESULT CALLBACK
n_calendar_wndproc( HWND hwnd, UINT msg, WPARAM wparam, LPARAM lparam )
{

	static n_posix_char *iconame = NULL;

#ifdef N_APPS_NAME_CALENDAR
	const  n_type_gfx iconindex = 1;
#else  // #ifdef N_APPS_NAME_CALENDAR
	const  n_type_gfx iconindex = 0;
#endif // #ifdef N_APPS_NAME_CALENDAR


	static NOTIFYICONDATA nid;
	static n_win_calendar cal;

	static n_bool onoff = n_false;

	static n_win_simplemenu menu;

	static int icon_supported[] = { 16, 32, 48, 0 };

	static UINT timer_id = 0;

	static UINT msg_explorer_crashed = WM_NULL;


	switch( msg ) {


	case WM_SETTINGCHANGE :

		// [!] : XP or later : this message is sent many times

		// [!] : Win8.1 : SPI_SETNONCLIENTMETRICS will never come

		if ( timer_id == 0 ) { timer_id = n_win_timer_id_get(); }
		n_win_timer_init( hwnd, timer_id, n_project_settingchange_interval() );

	break;

	case WM_TIMER :

		// [!] : Win95 needs to check WPARAM is ID or not

		if ( wparam == 0 ) { break; }

		if ( wparam == calendar.timer_id_lnch )
		{

			n_win_timer_exit( hwnd, calendar.timer_id_lnch );


			n_calendar_automove( hwnd );

			n_calendar_animatewindow( hwnd, n_true );

			SetForegroundWindow( hwnd );

		} else
		if ( wparam == calendar.timer_id_main )
		{

			n_win_timer_exit( hwnd, calendar.timer_id_main );

			onoff = n_false;

		} else
		if ( wparam == timer_id )
		{
			n_win_systray_icon_change( &nid, iconame, iconindex, icon_supported );

			n_win_stdfont_init( &cal.hgui, 1 );

			n_calendar_color( GetActiveWindow() );
		}

	break;


	case WM_NCHITTEST :

		if ( n_false == n_win_is_hovered( cal.hgui ) ) { return 0; }

	break;


	case WM_CREATE :


		// Global

		n_project_darkmode();

		n_game_timegettime_init();

		n_win_ime_disable( hwnd );

		msg_explorer_crashed = RegisterWindowMessage( n_posix_literal( "TaskbarCreated" ) );

		n_win_systray_icon_load_callback = n_calendar_systray_callback;


		n_calendar_zero( &calendar );
		calendar.id_tray = N_PROJECT_SYSTRAY_ID_NONNON_APPS_CALENDAR;

		n_win_exedir2curdir();
		iconame = n_win_exepath_new();

		n_calendar_color( GetActiveWindow() );


		// Window and Style

		n_win_init_literal( hwnd, "", "", "" );

		n_calendar_autostyle( hwnd );

		if ( n_win_fluent_ui_onoff )
		{
			n_calendar_resize( hwnd, cal.hgui );

			n_type_gfx csx, csy; n_win_size( hwnd, &csx, &csy );

			n_type_gfx round = n_win_fluent_ui_round_param( hwnd );

			n_win_fluent_ui_roundrect_region( hwnd, csx, csy, round );
		} else {
			n_calendar_resize( hwnd, cal.hgui );
		}

//n_win_style_new( hwnd, WS_OVERLAPPEDWINDOW );


		n_win_stdfont_init( &cal.hgui, 1 );


		n_memory_zero( &cal, sizeof( n_win_calendar ) );
		n_win_calendar_init( &cal, hwnd );


		n_win_simplemenu_zero( &menu );
		n_win_simplemenu_init( &menu );

		n_win_simplemenu_set( &menu, 0, NULL, n_posix_literal( "[ ]Register"   ), NULL );
		n_win_simplemenu_set( &menu, 1, NULL, n_posix_literal( "[ ]Unregister" ), NULL );
		n_win_simplemenu_set( &menu, 2, NULL, n_posix_literal( "[-]"           ), NULL );
		n_win_simplemenu_set( &menu, 3, NULL, n_posix_literal( "[ ]Exit"       ), NULL );


		n_win_topmost( hwnd, n_true );


		// Size

		ShowWindow( hwnd, SW_HIDE );


		// Display

		n_calendar_option();

		if ( calendar.sticky )
		{

			n_win_systray_init( &nid, hwnd, calendar.id_tray, iconame, N_CALENDAR_APPNAME, n_true );
			n_win_systray_icon_change( &nid, iconame, iconindex, icon_supported );

			// [!] : magic : prevent blinking

			SetFocus( GetParent( hwnd ) );

		} else {

			n_win_message_send( hwnd, N_WIN_SYSTRAY_MESSAGE, calendar.id_tray, N_CALENDAR_EVENT_LAUNCH );

		}

	break;


	case WM_PRINTCLIENT :
	{

		if ( calendar.border_onoff == n_false ) { break; }

		HDC hdc = (HDC) wparam;
		RECT r; GetClientRect( hwnd, &r );

		u32 color_fg = n_calendar_color_cache;
		u32 color_bg = n_win_darkmode_systemcolor_ui( COLOR_BTNFACE );
		u32 color__i = n_bmp_blend_pixel( color_fg, n_bmp_black, 0.15 );
		u32 color__o = n_bmp_blend_pixel( color_fg, n_bmp_black, 0.20 );

		n_win_box( hwnd, hdc, &r, n_bmp_colorref2argb( color__o ) );

		n_win_rect_resize( &r, -1, -1 ); 
		n_win_box( hwnd, hdc, &r, n_bmp_colorref2argb( color_fg ) );

		n_type_gfx border_sx, border_sy; n_calendar_border_size( &border_sx, &border_sy );
		n_win_rect_resize( &r, -border_sx + 2, -border_sy + 2 ); 
		n_win_box( hwnd, hdc, &r, n_bmp_colorref2argb( color__i ) );

		n_win_rect_resize( &r, -1, -1 ); 
		n_win_box( hwnd, hdc, &r, n_bmp_colorref2argb( color_bg ) );

	}
	break;


	case WM_ACTIVATE :

		if ( wparam == WA_INACTIVE )
		{

			if ( calendar.timer_id_main == 0 ) { calendar.timer_id_main = n_win_timer_id_get(); }
			n_win_timer_init( hwnd, calendar.timer_id_main, N_CALENDAR_TIMER_MSEC );

			if ( calendar.sticky )
			{
				n_calendar_animatewindow( hwnd, n_false );
				//ShowWindow( hwnd, SW_HIDE );
			} else {
				n_win_message_send( hwnd, WM_CLOSE, 0,0 );
			}

		}

	break;


	case N_WIN_SYSTRAY_MESSAGE :

		if ( wparam != calendar.id_tray ) { break; }


		if ( lparam == WM_LBUTTONDBLCLK )
		{

			int taskbar; n_win_taskbarpos( &taskbar, NULL );

			onoff = n_true;
			n_calendar_animatewindow( hwnd, n_false );
			//ShowWindow( hwnd, SW_HIDE );

			n_win_timer_exit( hwnd, calendar.timer_id_lnch );

		} else
		if ( lparam == N_CALENDAR_EVENT_LAUNCH )
		{

			if ( onoff )
			{
//n_posix_debug_literal( " N_WIN_SYSTRAY_MESSAGE " );

				onoff = n_false;

			} else {

				onoff = n_true;


				n_calendar_resize( hwnd, cal.hgui );


				if ( calendar.timer_id_lnch == 0 ) { calendar.timer_id_lnch = n_win_timer_id_get(); }
				n_win_timer_init( hwnd, calendar.timer_id_lnch, GetDoubleClickTime() / 2 );

			}

		} else
		if ( lparam == WM_RBUTTONUP )
		{
			if ( n_win_is_input( VK_CONTROL ) )
			{
				// [Needed] : to disappear a popup menu
				SetForegroundWindow( hwnd );
				n_win_simplemenu_show( &menu, hwnd );
			} else {
				n_win_message_send( hwnd, WM_CLOSE, 0,0 );
			}
		}

	break;


	case WM_KEYDOWN :

		if ( wparam == VK_ESCAPE )
		{
			n_win_message_send( hwnd, WM_ACTIVATE, WA_INACTIVE,0 );
		}

	break;


	case WM_COMMAND :

		if ( (HWND) lparam == menu.hwnd )
		{
			if ( wparam == N_WIN_SIMPLEMENU_WPARAM_REARRANGE )
			{
				//
			} else
			if ( wparam == 0 )
			{

				// [x] : Win95 : not supported
				//ShellExecute( hwnd, NULL, n_posix_literal( "shell:startup" ), NULL, NULL, SW_SHOWNORMAL );

				n_posix_char *rval = n_calendar_startup_commandline();

				n_project_startup_register( N_CALENDAR_APPNAME, rval );

				n_string_free( rval );

			} else
			if ( wparam == 1 )
			{

				n_project_startup_unregister( N_CALENDAR_APPNAME );

			} else
			if ( wparam == 2 )
			{

				// [!] : Separator

			} else
			if ( wparam == 3 )
			{

				n_win_message_send( hwnd, WM_CLOSE, 0,0 );

			}// else
		}

	break;


	case WM_CLOSE :

		n_calendar_animatewindow( hwnd, n_false );
		//ShowWindow( hwnd, SW_HIDE );


		n_win_calendar_exit( &cal, hwnd );

		n_win_timer_exit( hwnd, calendar.timer_id_main );

		n_win_stdfont_exit( &cal.hgui, 1 );

		n_win_systray_exit( &nid );

		n_win_simplemenu_exit( &menu );

		n_string_path_free( iconame );

		DestroyWindow( hwnd );

	break;

	case WM_DESTROY :

		PostQuitMessage( 0 );

	break;


	} // switch


	if ( msg == msg_explorer_crashed )
	{
		n_win_systray_exit( &nid );
		n_win_systray_init( &nid, hwnd, calendar.id_tray, iconame, N_CALENDAR_APPNAME, n_true );
	}


	n_win_calendar_proc( hwnd, msg, wparam, lparam, &cal );


	n_win_simplemenu_proc( hwnd, msg, &wparam, &lparam, &menu );


	return DefWindowProc( hwnd, msg, wparam, lparam );
}

#ifndef N_APPS_NAME_CALENDAR

int WINAPI
WinMain( HINSTANCE hinst, HINSTANCE hprv_hinst, LPSTR cmd, int show )
{
	return n_win_main( NULL, n_calendar_wndproc );
}

#endif // #ifndef N_APPS_NAME_CALENDAR


