// Nonnon Win32
// copyright (c) nonnon all rights reserved
// License : GPL http://www.gnu.org/copyleft/gpl.html




#include "../nonnon/win32/gdi/doublebuffer.c"
#include "../nonnon/win32/win.c"
#include "../nonnon/win32/gdi.c"

#include "../nonnon/game/progressbar.c"




static n_bool n_felis_addressbar_onoff = n_false;
static n_bool n_felis_progress_start   = n_false;




void
n_felis_addressbar_show( void )
{

	if ( n_felis_addressbar_onoff )
	{
		ShowWindow( H_URL,  SW_HIDE   );
		ShowWindow( H_OPEN, SW_NORMAL );
		SetFocus( H_OPEN );
		n_win_txtbox_line_select( &n_felis_txtbox_open, 0 );
	} else {
		ShowWindow( H_OPEN, SW_HIDE   );
		ShowWindow( H_URL,  SW_NORMAL );
	}


	return;
}

LRESULT CALLBACK
n_felis_addressbar_on_keydown( HWND hwnd, UINT msg, WPARAM wparam, LPARAM lparam )
{

	if ( wparam == VK_RETURN )
	{

		n_felis_addressbar_onoff = n_false;
		n_felis_addressbar_show();


		n_posix_char *str = n_win_txtbox_selection_new( &n_felis_txtbox_open );

		n_string_replace( str,str, N_STRING_CRLF, N_STRING_EMPTY );
		n_string_remove_blank( str,str );


		BSTR bstr = n_com_bstr_init( str );

		if ( n_false == n_felis_accesslist_is_blocklisted( bstr ) )
		{
			n_WebBrowser_go( n_felis_wb, bstr );
		}

		n_com_bstr_exit( bstr );


		n_string_path_free( str );


		return n_true;
	}


	return n_false;
}

void
n_felis_addressbar_exit( void )
{

	n_felis_progress_fade_phase = N_FELIS_PROGRESS_FADE_PHASE_NONE;
	n_felis_progress_stop_onoff = n_false;

	n_win_timer_exit( GetParent( H_URL ), n_felis_progress_timer_id );

	n_felis_progress_sx = 0;
	n_felis_progress_x  = 0;

	n_win_refresh( H_URL, n_false );


	return;
}

void
n_felis_addressbar_draw( HWND hgui, RECT *rect )
{
//n_win_box( hgui, NULL, rect, 0 ); return;


	n_type_gfx sx,sy; n_win_rect_expand_size( rect, NULL, NULL, &sx, &sy );


	HDC hdc = n_gdi_doublebuffer_32bpp_simple_init( hgui, sx,sy );


//n_win_hwndprintf_literal( n_win_hwnd_toplevel( hgui ), " %d ", n_felis_progress_finish );


	n_bool dwm_onoff = n_win_dwm_is_on();


	n_type_gfx scale = (n_type_gfx) trunc( n_win_scale( H_URL ) );


	// Background

	if ( n_win_darkmode_onoff )
	{
		n_win_box( hgui, hdc, rect, n_win_darkmode_systemcolor_ui( COLOR_BTNFACE ) );
	} else
	if ( n_win_dwm_aeroglass_is_on() )
	{
		n_win_box( hgui, hdc, rect, 0 );
	} else {
		// [x] : Win9x : n_win_darkmode_systemcolor() only
		n_win_box( hgui, hdc, rect, n_win_darkmode_systemcolor( COLOR_BTNFACE ) );
	}


	// Chunk

	//if ( 0 )
	{

		RECT r; n_win_rect_set( &r, n_felis_progress_x, 0, n_felis_progress_sx, sy );

		n_win_rect_resize( &r, -scale, -scale );

		n_type_gfx tsx,tsy; n_win_rect_expand_size( &r, NULL, NULL, &tsx, &tsy );


		u32 color = n_win_dwm_windowcolor_arranged();
		color = n_bmp_lightness_replace_pixel( color, 100 );


		n_bool     p_no_round = n_game_progressbar_no_round; 
		n_type_gfx p_border   = n_game_progressbar_border;
		n_type_gfx p_div      = n_game_progressbar_round_div;

		n_game_progressbar_no_round  = n_true;
		n_game_progressbar_border    = scale;

		n_game_progressbar_animation          = N_GAME_PROGRESSBAR_ANIMATION_ON_UP;
		n_game_progressbar_animation_interval = 10;


		n_bmp bmp; n_bmp_zero( &bmp );
		n_gdi gdi; n_gdi_zero( &gdi );

		gdi.sx            = tsx;
		gdi.sy            = tsy;
		gdi.style         = N_GDI_DEFAULT;
		gdi.base_style    = N_GDI_BASE_PROGRESS_H;
		gdi.base_color_fg = color;
		gdi.base_color_bg = color;
		gdi.percent       = 100;

		n_gdi_bmp( &gdi, &bmp );


		n_game_progressbar_no_round  = p_no_round;
		n_game_progressbar_border    = p_border;
		n_game_progressbar_round_div = p_div;


		if ( n_felis_progress_fade_phase != N_FELIS_PROGRESS_FADE_PHASE_NONE )
		{

			if ( n_felis_progress_fade_phase == N_FELIS_PROGRESS_FADE_PHASE_INIT )
			{

				n_felis_progress_fade_phase = N_FELIS_PROGRESS_FADE_PHASE_LOOP;

				n_bmp_fade_init( &n_felis_progress_fade, n_bmp_black );
				n_bmp_fade_go  ( &n_felis_progress_fade, n_bmp_white );
//n_win_hwndprintf_literal( GetParent( H_BAND ), " %d ", n_felis_progress_fade.percent );

			}


			n_bmp_fade_engine( &n_felis_progress_fade, n_true );
//n_win_hwndprintf_literal( GetParent( H_BAND ), " %d ", n_felis_progress_fade.percent );


			n_bmp_blendcopy
			(
				&bmp, &n_gdi_doublebuffer_32bpp_instance.bmp,
				0, 0, gdi.sx, gdi.sy,
				n_felis_progress_x, scale,
				(n_type_real) n_felis_progress_fade.percent * 0.01
			);


			if ( n_felis_progress_fade.percent == 100 )
			{
				n_felis_addressbar_exit();
			}

		} else {

			n_bmp_fastcopy
			(
				&bmp, &n_gdi_doublebuffer_32bpp_instance.bmp,
				0, 0, gdi.sx, gdi.sy,
				n_felis_progress_x, scale
			);

		}

		n_bmp_free_fast( &bmp );

	}


	// Border

	//if ( 0 )
	{

		u32 color_border;
		if ( n_win_darkmode_onoff )
		{
			color_border = n_bmp_rgb( 100,100,100 );
		} else
		if ( n_win_style_is_classic() )
		{
			color_border = n_win_darkmode_systemcolor_colorref2argb_ui( COLOR_BTNSHADOW );
		} else {
			u32 color_f = n_win_darkmode_systemcolor_colorref2argb_ui( COLOR_WINDOW     );
			u32 color_t = n_win_darkmode_systemcolor_colorref2argb_ui( COLOR_WINDOWTEXT );
			color_border = n_bmp_blend_pixel( color_f, color_t, 0.25 );
		}

		if ( n_felis_txtbox_open.style_option & N_WIN_TXTBOX_OPTION_ONELINE_ROUNDRC )
		{
			n_bmp *bmp = &n_gdi_doublebuffer_32bpp_instance.bmp;
			n_bmp_roundrect_pixel( bmp, 0,0,sx,sy, color_border, 4 * scale );
		} else {
			n_win_frame( hdc, 0,0,sx,sy, color_border );
		}

	}


	// Text

	const int dt = DT_CENTER | ( DT_SINGLELINE | DT_VCENTER ) | DT_NOPREFIX | DT_WORD_ELLIPSIS;

	//if ( 0 )
	{

		COLORREF color = n_win_darkmode_systemcolor_ui( COLOR_BTNTEXT );

		HFONT  hfont = n_win_font_get( hgui );
		HFONT phfont = SelectObject( hdc, hfont );

		SetBkMode( hdc, TRANSPARENT );

		n_posix_char *str = n_win_text_new( hgui );
//n_posix_debug_literal( " %s ", str );

		if ( dwm_onoff )
		{

			n_uxtheme uxtheme; n_uxtheme_zero( &uxtheme );
			n_uxtheme_init( &uxtheme, hgui, L"PROGRESS" );

			n_posix_bool prj_dwm_onoff = n_project_dwm_is_on();

			n_type_gfx i = 0;
			while( prj_dwm_onoff )
			{

				n_uxtheme_draw_text_contour_onoff = n_true;
				n_uxtheme_draw_text( &uxtheme, hgui, hdc, rect, 0,0, dt, TMT_MENUFONT, n_true );
				n_uxtheme_draw_text_contour_onoff = n_false;

				n_bmp_flush_antialias( &n_gdi_doublebuffer_32bpp_instance.bmp, 1.0 );

				i++;
				if ( i >= ( 2 * scale ) ) { break; }
			}

			//n_uxtheme_draw_text_glow_onoff = n_true;
			n_uxtheme_draw_text( &uxtheme, hgui, hdc, rect, 0,0, dt, TMT_MENUFONT, n_true );
			//n_uxtheme_draw_text_glow_onoff = n_false;

			n_uxtheme_exit( &uxtheme, hgui );


			if ( n_win_darkmode_onoff )
			{
				//
			} else {
				n_bmp_flush_mirror( &n_gdi_doublebuffer_32bpp_instance.bmp, N_BMP_MIRROR_UPSIDE_DOWN );
			}

		} else {

			SetTextColor( hdc, color );
			DrawText( hdc, str, (int) n_posix_strlen( str ), rect, dt );

		}

		n_string_free( str );

		SelectObject( hdc, phfont );

	}


	if ( n_false == dwm_onoff )
	{
		n_bmp_alpha_visible( &n_gdi_doublebuffer_32bpp_instance.bmp );
	}


	n_gdi_doublebuffer_32bpp_exit( &n_gdi_doublebuffer_32bpp_instance );


	return;
}

void
n_felis_addressbar_progress_start( n_bool timer_onoff, u32 timer_delay_msec )
{

	if ( timer_onoff )
	{
		n_felis_progress_timer_delay = n_posix_tickcount() + timer_delay_msec;

		if ( n_felis_progress_timer_id == 0 ) { n_felis_progress_timer_id = n_win_timer_id_get(); }
		n_win_timer_init( GetParent( H_URL ), n_felis_progress_timer_id, 10 );
	}


	n_felis_progress_start = n_true;


	n_win_size_client( H_URL, &n_felis_progress_sx, NULL );

	n_felis_progress_sx = n_posix_max( 200, n_felis_progress_sx / 5 );
	n_felis_progress_x  = -n_felis_progress_sx;


	n_felis_progress_fade_phase = N_FELIS_PROGRESS_FADE_PHASE_NONE;


	return;
}

void
n_felis_addressbar_progress_stop( void )
{

	n_felis_progress_start = n_false;

	if ( n_felis_progress_fade_phase == N_FELIS_PROGRESS_FADE_PHASE_NONE )
	{
		n_felis_progress_fade_phase = N_FELIS_PROGRESS_FADE_PHASE_INIT;
	}


	return;
}

void
n_felis_addressbar_proc( HWND hwnd, UINT msg, WPARAM wparam, LPARAM lparam, HWND hgui )
{

	switch( msg ) {


	case WM_TIMER :

		if ( wparam == 0 ) { break; }

		if ( wparam == n_felis_progress_timer_id )
		{

			if ( n_felis_progress_timer_delay < n_posix_tickcount() )
			{

				n_type_gfx sx; n_win_size_client( H_URL, &sx, NULL );

				if ( n_felis_progress_x >= sx )
				{
					if ( n_felis_progress_stop_onoff )
					{
						n_felis_addressbar_progress_stop();
					} else {
						n_felis_addressbar_progress_start( n_false, 0 );
					}
				}
//n_win_hwndprintf_literal( GetParent( hwnd ), " %d / %d ", n_felis_progress_x, sx );

				n_felis_progress_x += n_posix_max( 4, sx / 200 );
				n_win_refresh( hgui, n_false );

			} else
			if ( n_felis_progress_stop_onoff )
			{
				n_felis_addressbar_progress_stop();
			}

		}

	break;


	case WM_PAINT :

		n_win_refresh( hgui, n_false );

	break;


	case WM_DRAWITEM :
	{

		// [Needed] : FixedSys is used at exit
		if ( n_felis_addressbar_draw_onoff == n_false ) { break; }


		DRAWITEMSTRUCT *di = (void*) lparam;

		if ( di == NULL ) { break; }
		if ( hgui != di->hwndItem ) { break; }


		n_felis_addressbar_draw( hgui, &di->rcItem );

	}
	break;


	} // switch


	return;
}

