// nmemo
// copyright (c) nonnon all rights reserved
// License : GPL http://www.gnu.org/copyleft/gpl.html




#ifndef NONNON_APPS

#include "../nonnon/project/define_unicode.c"

//#define N_MEMORY_DEBUG

#include "../nonnon/game/timegettime.c"

#endif // #ifndef NONNON_APPS




// [!] : Instance

#ifndef NONNON_APPS

#define N_APPS_ICON_OFFSET_NMEMO ( 0 )

#endif // #ifndef NONNON_APPS




#include "../nonnon/win32/win.c"
#include "../nonnon/win32/win_txtbox.c"

#include "../nonnon/win32/explorer.c"


#include "../nonnon/project/macro.c"




#define N_NMEMO_SECTION "Nonnon Memo"
#define N_NMEMO_TXTNAME n_posix_literal( "nmemo.txt" )




static n_win n_nmemo_nwin;
static n_win n_nmemo_nwin_ini;

static n_win_txtbox n_nmemo_txtbox;
static HFONT        n_nmemo_hfont = NULL;




// internal
void
n_nmemo_day_of_week( n_posix_char *str, n_type_int cch )
{

	// [Needed] : an explicit name like "ja-JP" will not work

	setlocale( LC_ALL, "" );


	time_t     rawtime; time( &rawtime );
	struct tm *timeinfo = localtime( &rawtime );

	n_posix_strftime_literal( str, cch, "%A", timeinfo );

//n_posix_debug_literal( "%s", str );

	return;

}




// internal
void
n_nmemo_ini_read( void )
{

	n_win_zero( &n_nmemo_nwin );


	n_ini ini; n_ini_zero( &ini );
	n_ini_load( &ini, n_project_ini_name );

	n_nmemo_nwin.posx = n_ini_value_int_literal( &ini, N_NMEMO_SECTION, "posx", -1 );
	n_nmemo_nwin.posy = n_ini_value_int_literal( &ini, N_NMEMO_SECTION, "posy", -1 );
	n_nmemo_nwin.rcsx = n_ini_value_int_literal( &ini, N_NMEMO_SECTION, "rcsx", -1 );
	n_nmemo_nwin.rcsy = n_ini_value_int_literal( &ini, N_NMEMO_SECTION, "rcsy", -1 );
//n_posix_debug_literal( " %d %d %d %d ", n_nmemo_nwin.posx, n_nmemo_nwin.posy, n_nmemo_nwin.rcsx, n_nmemo_nwin.rcsy );

	n_ini_free( &ini );


	return;
}

// internal
void
n_nmemo_ini_write( void )
{

	n_ini ini;n_ini_zero( &ini );
	n_ini_load( &ini, n_project_ini_name );

	n_ini_section_add_literal( &ini, N_NMEMO_SECTION );

	n_ini_key_add_int_literal( &ini, N_NMEMO_SECTION, "posx", n_nmemo_nwin_ini.posx );
	n_ini_key_add_int_literal( &ini, N_NMEMO_SECTION, "posy", n_nmemo_nwin_ini.posy );
	n_ini_key_add_int_literal( &ini, N_NMEMO_SECTION, "rcsx", n_nmemo_nwin_ini.rcsx );
	n_ini_key_add_int_literal( &ini, N_NMEMO_SECTION, "rcsy", n_nmemo_nwin_ini.rcsy );

	n_ini_save( &ini, n_project_ini_name );
	n_ini_free( &ini );


	n_explorer_refresh( n_false );


	return;
}




void
n_nmemo_font( HWND hgui )
{

	LOGFONT lf = n_win_font_hwnd2logfont( hgui );

	lf.lfHeight *= 2;

	n_nmemo_hfont = n_win_font_logfont2hfont( &lf );

	n_win_font_set( hgui, n_nmemo_hfont, n_true );


	return;
}

void
n_nmemo_resize( HWND hwnd, HWND hgui )
{

	const n_bool redraw = n_true;


	static n_bool is_first = n_true;

	if ( is_first )
	{

		is_first = n_false;


		int nwset = N_WIN_SET_INNERPOS;

		if ( ( n_nmemo_nwin.posx == -1 )||( n_nmemo_nwin.posy == -1 ) )
		{
			nwset |= N_WIN_SET_CENTERING;
		} else {
			nwset |= N_WIN_SET_NEEDPOS;
		}

		if ( ( n_nmemo_nwin.rcsx == -1 )||( n_nmemo_nwin.rcsy == -1 ) )
		{
			n_type_gfx desktop_sx, desktop_sy; n_win_desktop_size( &desktop_sx, &desktop_sy );

			n_type_gfx size = n_posix_min( desktop_sx, desktop_sy ) / 3;

			n_nmemo_nwin.rcsx = size;
			n_nmemo_nwin.rcsy = size;
		}

//n_posix_debug_literal( " %d %d %d %d ", n_nmemo_nwin.posx, n_nmemo_nwin.posy, n_nmemo_nwin.rcsx, n_nmemo_nwin.rcsy );
		n_win_set( hwnd, &n_nmemo_nwin, n_nmemo_nwin.rcsx,n_nmemo_nwin.rcsy, nwset );

	} else {

		n_win_set( hwnd, &n_nmemo_nwin, -1,-1, n_project_n_win_set() );

	}


	MoveWindow( hgui, 0,0,n_nmemo_nwin.csx,n_nmemo_nwin.csy, redraw );


	n_win_topmost( hwnd, n_true );


	return;
}

LRESULT CALLBACK
n_nmemo_wndproc( HWND hwnd, UINT msg, WPARAM wparam, LPARAM lparam )
{

	static UINT timer_id = 0;


	switch( msg ) {


	case WM_SETTINGCHANGE :

		// [!] : XP or later : this message is sent many times

		// [!] : Win8.1 : SPI_SETNONCLIENTMETRICS will never come

		if ( timer_id == 0 ) { timer_id = n_win_timer_id_get(); }
		n_win_timer_init( hwnd, timer_id, n_project_settingchange_interval() );

	break;


	case WM_TIMER :

		// [!] : Win95 needs to check WPARAM is ID or not

		if ( wparam == 0 ) { break; }

		if ( wparam != timer_id ) { break; }
		n_win_timer_exit( hwnd, timer_id );


		n_project_darkmode();

		n_win_init_background( hwnd );
		n_win_refresh( hwnd, n_true );


		n_win_txtbox_metrics( &n_nmemo_txtbox );


		if ( n_posix_false == n_sysinfo_version_10_or_later() )
		{
			if ( n_win_dwm_is_on() )
			{
				n_win_exstyle_add( hwnd, WS_EX_TOOLWINDOW );
			} else {
				n_win_exstyle_del( hwnd, WS_EX_TOOLWINDOW );
			}
			SetWindowPos( hwnd, NULL, 0,0,0,0, SWP_NOSIZE | SWP_NOMOVE | SWP_FRAMECHANGED );
		}

	break;


	case WM_CREATE :

		n_win_txtbox_zero( &n_nmemo_txtbox );


		n_win_exedir2curdir();

		n_project_darkmode();

		n_nmemo_ini_read();


		n_win_init_literal( hwnd, "nmemo", "", "" );


		// [!] : WinXP/Luna : need to set WS_EX_DLGMODALFRAME before WS_*

		n_win_exstyle_new( hwnd, WS_EX_DLGMODALFRAME           );
		n_win_style_new  ( hwnd, N_WS_POPUPWINDOW | WS_SIZEBOX );

		n_win_sysmenu_disable( hwnd, 1,0,0, 1,1, 0, 0 );


		if ( n_posix_false == n_sysinfo_version_10_or_later() )
		{
			if ( n_win_dwm_is_on() )
			{
				n_win_exstyle_add( hwnd, WS_EX_TOOLWINDOW );
			} else {
				n_win_exstyle_del( hwnd, WS_EX_TOOLWINDOW );
			}
			SetWindowPos( hwnd, NULL, 0,0,0,0, SWP_NOSIZE | SWP_NOMOVE | SWP_FRAMECHANGED );
		}


		{
			int style = 0;

			style = style | N_WIN_TXTBOX_STYLE_EDITBOX;
			style = style | N_WIN_TXTBOX_STYLE_VSCROLL;
			style = style | N_WIN_TXTBOX_STYLE_STRIPED;

			int style_option = 0;

			//style_option = style_option | N_WIN_TXTBOX_OPTION_EDITBOX_LINENUM;
			style_option = style_option | N_WIN_TXTBOX_OPTION_EDITBOX_NOIBEAM;

			n_win_txtbox_init( &n_nmemo_txtbox, hwnd, style, style_option );
		}


		n_win_txtbox_txt_load( &n_nmemo_txtbox, N_NMEMO_TXTNAME );
		n_nmemo_txtbox.txt.unicode = N_TXT_UNICODE_UTF;


		n_nmemo_font( n_nmemo_txtbox.hwnd );

		SetFocus( n_nmemo_txtbox.hwnd );


		n_nmemo_resize( hwnd, n_nmemo_txtbox.hwnd );


		ShowWindow( hwnd, SW_NORMAL );

	break;


	case WM_MOVE :

		if ( n_false == IsZoomed( hwnd ) )
		{
			RECT r; GetWindowRect( hwnd, &r );
			n_nmemo_nwin_ini.posx = r.left;
			n_nmemo_nwin_ini.posy = r.top;
		}

	break;

	case WM_SIZE :

		n_nmemo_resize( hwnd, n_nmemo_txtbox.hwnd );

		if ( wparam == SIZE_RESTORED )
		{
			n_win_size_client( hwnd, &n_nmemo_nwin_ini.rcsx, &n_nmemo_nwin_ini.rcsy );
		}

	break;


	case WM_SETFOCUS :

		SetFocus( n_nmemo_txtbox.hwnd );

	break;


	case WM_KEYDOWN :
/*
		// [!] : UxTheme : SetWindowPos() is needed

		if ( wparam == VK_F1 )
		{
			n_win_exstyle_new( hwnd, WS_EX_DLGMODALFRAME | WS_EX_TOOLWINDOW );
			SetWindowPos( hwnd, NULL, 0,0,0,0, SWP_NOSIZE | SWP_NOMOVE | SWP_FRAMECHANGED );
		} else
		if ( wparam == VK_F2 )
		{
			n_win_exstyle_new( hwnd, WS_EX_DLGMODALFRAME );
			SetWindowPos( hwnd, NULL, 0,0,0,0, SWP_NOSIZE | SWP_NOMOVE | SWP_FRAMECHANGED );
		} else
*/
		if ( wparam == VK_F5 )
		{

			n_posix_char str[ 100 ];

			if ( n_win_is_input( VK_CONTROL ) )
			{
				n_nmemo_day_of_week( str, 100 );
			} else {
				n_time_string_stime( str );
			}

			n_win_txtbox_selection_cat( &n_nmemo_txtbox,  str );

			n_win_txtbox_refresh( &n_nmemo_txtbox, N_WIN_TXTBOX_NMEMO );

		}

	break;


	case WM_CLOSE :

		ShowWindow( hwnd, SW_HIDE );

		n_nmemo_ini_write();

		n_win_font_set( n_nmemo_txtbox.hwnd, n_win_font_default( n_nmemo_txtbox.hwnd, n_false ), n_false );
		n_win_font_exit( n_nmemo_hfont );

		n_win_txtbox_txt_save( &n_nmemo_txtbox, N_NMEMO_TXTNAME );
		n_win_txtbox_exit( &n_nmemo_txtbox );

		DestroyWindow( hwnd );

	break;

	case WM_DESTROY :

		PostQuitMessage( 0 );

	break;


	} // switch


	{
		int ret = n_win_txtbox_proc( hwnd, msg, wparam, lparam, &n_nmemo_txtbox );
		if ( ret ) { return ret; }
	}


	n_win_simplemenu_proc( hwnd, msg, &wparam, &lparam, NULL );


	return DefWindowProc( hwnd, msg, wparam, lparam );
}

#ifndef NONNON_APPS

int WINAPI
WinMain( HINSTANCE hinst, HINSTANCE prv_hinst, LPSTR cmd, int show )
{
	return n_win_main( NULL, n_nmemo_wndproc );
}

#endif // #ifndef NONNON_APPS

