// Marie
// copyright (c) nonnon all rights reserved
// License : GPL http://www.gnu.org/copyleft/gpl.html


// [x]
//
//	[ Access Time ]
//
//	+ stat() doesn't overwrite access time
//	+ Explorer's property overwrites access time
//
//	[ MP3 ID3-V2 Tag ]
//
//	+ vfw cannot play the files have 2.4 or higher version
//
//	[ Volume Normalization ]
//
//	+ loudness might be different in each songs
//	+ ripping software cannot resolve well




#include "../nonnon/neutral/dir.c"
#include "../nonnon/neutral/random.c"
#include "../nonnon/neutral/txt.c"

#include "../nonnon/win32/sysinfo/version_misc.c"




// inherit

#define n_jukebox       n_dir

#define n_jukebox_zero  n_dir_zero
#define n_jukebox_free  n_dir_free

#define n_jukebox_new   n_dir_new

#define n_jukebox_add   n_dir_add
#define n_jukebox_del   n_dir_del

#define n_jukebox_count n_dir_all

#define n_jukebox_path  n_dir_path
#define n_jukebox_name  n_dir_name
#define n_jukebox_low   n_dir_low
#define n_jukebox_ext   n_dir_ext

#define n_jukebox_load_recursive n_dir_load_recursive




static n_bool n_jukebox_is_m3u = n_false;




n_bool
n_jukebox_is_empty( n_jukebox *jb )
{

	if ( jb == NULL ) { return n_true; }


	n_type_int count = n_jukebox_count( jb );

	if ( count == 0 ) { return n_true; }
	if ( ( count == 1 )&&( n_string_is_empty( n_jukebox_name( jb, 0 ) ) ) ) { return n_true; }


	return n_false;
}

void
n_jukebox_shuffle( n_jukebox *jb )
{

	if ( 1 >= n_jukebox_count( jb ) ) { return; }

	if ( n_jukebox_is_m3u ) { return; }


	n_random_shuffle();

	n_type_int i = 0;
	n_posix_loop
	{

		n_type_int r = n_random_range_hq( (u32) n_jukebox_count( jb ) );

		n_vector_swap( &jb->path, i, r );
		n_vector_swap( &jb->name, i, r );
		n_vector_swap( &jb->low,  i, r );
		n_vector_swap( &jb->ext,  i, r );

		i++;
		if ( i >= n_jukebox_count( jb ) ) { break; }
	}


	return;
}

n_posix_char*
n_jukebox_next_new( n_jukebox *jb )
{

	if ( n_jukebox_is_empty( jb ) ) { return NULL; }


	n_posix_char *ret = n_string_path_make_new( n_jukebox_path( jb, 0 ), n_jukebox_name( jb, 0 ) );

	n_jukebox_del( jb, 0 );

//n_posix_debug_literal( "%s \n %d \n %d", ret, n_jukebox_count( jb ), n_jukebox_is_empty( jb ) );

	if ( n_jukebox_is_empty( jb ) )
	{
		n_jukebox_free( jb );
	} else {
		n_jukebox_shuffle( jb );
	}


	return ret;
}

n_bool
n_jukebox_wma_is_supported( void )
{

	n_bool ret = n_false;


	n_posix_char str[ 100 ];
	int          major = n_sysinfo_version_wmp( str );

	if (
		( major >= 7 )
		||
		(
			( major >= 6 )
			&&
			( n_string_str2real( &str[ 2 ] ) >= 4 )
		)
	)
	{
		ret = n_true;
	}

//n_posix_debug_literal( "%s : %d", str, ret );


	return ret;
}

n_bool
n_jukebox_m3u_load( n_jukebox *jb, n_posix_char *path )
{

	// [ Mechanism ]
	//
	//	simple format only


	// [!] : sniffer

	if (
		( n_false == n_string_path_ext_is_same_literal( ".m3u\0\0",  path ) )
		&&
		( n_false == n_string_path_ext_is_same_literal( ".m3u8\0\0", path ) )
	)
	{
		return n_true;
	}


	n_txt txt; n_txt_zero( &txt );
	if ( n_txt_load( &txt, path ) ) { return n_true; }

	n_jukebox_free( jb );
	n_jukebox_new ( jb );

	n_type_int i = txt.sy - 1;
	n_posix_loop
	{

		n_posix_char *str = n_txt_get( &txt, i );
		if (
			( str[ 0 ] == n_posix_literal( '#' ) )
			||
			( n_string_is_empty( str ) )
		)
		{
			n_txt_del( &txt, i );
		}

		if ( i == 0 ) { break; }
		i--;

	}


	n_posix_char *dir = n_string_path_upperfolder_new( path );

	i = 0;
	n_posix_loop
	{//break;

		const n_posix_char *line = n_txt_get( &txt, i );

		n_posix_char *abspath;
		if ( n_string_path_is_abspath( line ) )
		{
			abspath = n_string_path_carboncopy( line );
		} else {
			abspath = n_string_path_make_new( dir, line );
		}

		n_posix_char *name = n_string_path_name_new( abspath );
		n_posix_char *fldr = n_string_path_upperfolder_new( abspath );
//n_posix_debug_literal( "%s\n%s\n%s", abspath, name, fldr ); break;

		n_jukebox_add( jb, fldr, name, abspath );

		n_string_path_free( abspath );
		n_string_path_free(    name );
		n_string_path_free(    fldr );

		i++;
		if ( i >= txt.sy ) { break; }
	}
//n_vector_debug( &jb->name );
//n_vector_save_literal( &jb->name, "name.txt", N_STRING_CRLF );

	n_string_path_free( dir );


	n_txt_free( &txt );


//n_posix_debug_literal( "!" );
	return n_false;
}

void
n_jukebox_m3u_save( n_jukebox *jb, n_posix_char *path, n_bool is_inner )
{

	n_posix_char *name;
	if ( is_inner )
	{
		n_posix_char *folder = n_string_path_name_new( path );
		name = n_string_path_make_new( path, folder );
		n_string_path_free( folder );
	} else {
		name = n_string_path_carboncopy( path );
	}
	n_posix_char *m3u = n_string_path_ext_mod_new( name, n_posix_literal( ".m3u\0\0" ) );

	n_string_path_free( name );
	name = m3u;


	// [x] : Non-Unicode only

	n_txt txt; n_txt_zero( &txt ); n_txt_new( &txt );
	txt.unicode = N_TXT_UNICODE_NIL;

	n_type_int i = 0;
	n_posix_loop
	{

		n_posix_char *str = n_string_path_make_new( n_jukebox_path( jb, i ), n_jukebox_name( jb, i ) );
//n_posix_debug_literal( "%s", str ); break;

		n_posix_char *upper = n_string_path_upperfolder_new( path );

		n_posix_char *rel = NULL;
		if ( is_inner ) { rel = path; } else { rel = upper; }

		n_posix_sprintf_literal( str, "%s", &str[ n_posix_strlen( rel ) ] );
		n_string_copy( &str[ 1 ], str );
//n_posix_debug_literal( "%s", str );// break;

		n_txt_set( &txt, 0, str );

		n_string_path_free( upper );
		n_string_path_free( str   );

		i++;
		if ( i >= n_jukebox_count( jb ) ) { break; }
	}


	if ( n_txt_save( &txt, name ) )
	{
		n_posix_char *m3u8 = n_string_path_ext_mod_new( name, n_posix_literal( ".m3u8\0\0" ) );
		n_string_path_free( name );
		name = m3u8;

		txt.unicode = N_TXT_UNICODE_UTF;
		n_txt_save( &txt, name );
	}


	n_txt_free( &txt );


	n_string_path_free( name );


	return;
}

void
n_jukebox_register( n_jukebox *jb )
{

	n_bool wma_onoff = n_jukebox_wma_is_supported();


	n_type_int i = 0;
	n_posix_loop
	{

		if (
			( n_string_is_same_literal( ".wav", n_jukebox_ext( jb, i ) ) )
			||
			( n_string_is_same_literal( ".mp3", n_jukebox_ext( jb, i ) ) )
			||
			(
				( wma_onoff )
				&&
				( n_string_is_same_literal( ".wma", n_jukebox_ext( jb, i ) ) )
			)
		)
		{
			// [!] : do nothing
		} else {
			n_jukebox_del( jb, i );
			i--;
		}

		i++;
		if ( i >= n_jukebox_count( jb ) ) { break; }
	}


	return;
}

n_bool
n_jukebox_m3u_shuffle_save( n_posix_char *path, n_bool is_inner )
{

	n_bool ret = n_true;


	n_jukebox jukebox; n_jukebox *jb = &jukebox; n_jukebox_zero( jb );


	if ( n_jukebox_load_recursive( jb, path ) ) { return ret; }


	n_jukebox_register( jb );


	if ( n_false == n_jukebox_is_empty( jb ) )
	{

		// [x] : sorting is very heavy

		//n_jukebox_sort_atime( jb );
		n_jukebox_shuffle( jb );


		n_posix_char *curdir = n_string_path_folder_current_new();

		n_string_path_folder_change( path );

		n_jukebox_m3u_save( jb, path, is_inner );

		n_string_path_folder_change( curdir );

		n_string_path_free( curdir );

//n_vector_save_literal( &jb->name, "name.txt", N_STRING_CRLF );

		ret = n_false;

	}


	n_jukebox_free( jb );


	return ret;
}

n_bool
n_jukebox_load( n_jukebox *jb, n_posix_char *path )
{

	n_jukebox_free( jb );


	n_jukebox_is_m3u = n_false;

	{ // Load

		n_bool error = n_false;

		if ( n_jukebox_m3u_load( jb, path ) )
		{
			error = n_true;
		} else {
			n_jukebox_is_m3u = n_true;
		}

		if ( error )
		{
			if ( n_jukebox_load_recursive( jb, path ) )
			{
				error = n_true;
			} else {
				error = n_false;
			}
		}

		if ( error ) { return n_true; }

	} // Load
//n_posix_debug_literal( "%d", n_jukebox_count( jb ) );


	n_jukebox_register( jb );

//n_posix_debug_literal( "%d", n_jukebox_count( jb ) );


	if ( n_jukebox_is_empty( jb ) )
	{

		n_jukebox_free( jb );

		return n_true;

	} else
	if ( n_jukebox_is_m3u )
	{

		//

	} else {

		// [x] : sorting is very heavy

		//n_jukebox_sort_atime( jb );
		n_jukebox_shuffle( jb );

	}


	return n_false;
}

