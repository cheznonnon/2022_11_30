// Nonnon Image Info
// copyright (c) nonnon all rights reserved
// License : GPL http://www.gnu.org/copyleft/gpl.html


// Partial File




void
n_imageinfo_png( n_posix_char *name, n_win_txtbox *txtbox )
{

	const int _png_byte = 8;
	const int unit_byte = 4 + 4;
	const int ihdr_byte = unit_byte + 13 + 4;
	const int minimbyte = _png_byte + ihdr_byte + unit_byte;

	if ( minimbyte > n_posix_stat_size( name ) ) { return; }


	n_png png; n_png_zero( &png );


	FILE *fp = n_posix_fopen_read( name );
	if ( fp != NULL )
	{
		n_posix_fread( &png._png, _png_byte + ihdr_byte, 1, fp );
	}
	fclose( fp );


	n_posix_char *str = n_string_new( 1024 * 1024 );


	n_posix_sprintf_literal
	(
		str,

		"[ PNG Header ]\n"
		"u8   _png[ 0 ]        = 0x%02x\n"
		"u8   _png[ 1 ]        = %c\n"
		"u8   _png[ 2 ]        = %c\n"
		"u8   _png[ 3 ]        = %c\n"
		"u8   _png[ 4 ]        = 0x%02x\n"
		"u8   _png[ 5 ]        = 0x%02x\n"
		"u8   _png[ 6 ]        = 0x%02x\n"
		"u8   _png[ 7 ]        = 0x%02x\n"
		"\n"
		"[ Chunk : IHDR ]\n"
		"u32  ihdr_byte        = %lu\n"
		"u8   ihdr_header[ 0 ] = %c\n"
		"u8   ihdr_header[ 1 ] = %c\n"
		"u8   ihdr_header[ 2 ] = %c\n"
		"u8   ihdr_header[ 3 ] = %c\n"
		"u32  ihdr_sx          = %lu\n"
		"u32  ihdr_sy          = %lu\n"
		"u8   ihdr_bit         = %d\n"
		"u8   ihdr_mode        = %d\n"
		"u8   ihdr_compress    = %d\n"
		"u8   ihdr_filter      = %d\n"
		"u8   ihdr_interlace   = %d\n"
		"u32  ihdr_crc         = 0x%x\n",

		png._png[ 0 ],
		png._png[ 1 ],
		png._png[ 2 ],
		png._png[ 3 ],
		png._png[ 4 ],
		png._png[ 5 ],
		png._png[ 6 ],
		png._png[ 7 ],

		n_endian_big( png.ihdr_byte, 4 ),
		png.ihdr_header[ 0 ],
		png.ihdr_header[ 1 ],
		png.ihdr_header[ 2 ],
		png.ihdr_header[ 3 ],
		n_endian_big( png.ihdr_sx, 4 ),
		n_endian_big( png.ihdr_sy, 4 ),
		png.ihdr_bit,
		png.ihdr_mode,
		png.ihdr_compress,
		png.ihdr_filter,
		png.ihdr_interlace,
		png.ihdr_crc
	);


	n_win_txtbox_txt_load_onmemory( txtbox, str, 1024 * 1024 );


	return;
}


