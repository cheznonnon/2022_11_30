// Nonnon Image Info
// copyright (c) nonnon all rights reserved
// License : GPL http://www.gnu.org/copyleft/gpl.html




#ifndef NONNON_APPS

#include "../nonnon/project/define_unicode.c"

#endif // #ifndef NONNON_APPS




#include "../nonnon/win32/win.c"
#include "../nonnon/win32/win_txtbox.c"

#include "../nonnon/project/macro.c"




#include "./_bmp.c"
#include "./_curico.c"
#include "./_png.c"




typedef struct {

	n_win_txtbox txtbox;
	HFONT        hfont;

} n_imageinfo;


static n_imageinfo nii;




// internal
void
n_imageinfo_resize( HWND hwnd )
{

	const n_posix_bool redraw = n_posix_true;


	n_type_gfx m; n_win_stdsize( hwnd, NULL, NULL, &m );


	static n_posix_bool is_first = n_posix_true;


	int nwset = N_WIN_SET_DEFAULT;

	n_type_gfx csx = -1;
	n_type_gfx csy = -1;

	if ( is_first )
	{

		is_first = n_posix_false;

		nwset = N_WIN_SET_CENTERING;

		csx = 512;
		csy = 512;

	} else {

		nwset = n_project_n_win_set();

	}


	n_win w;
	n_win_set( hwnd, &w, csx,csy, nwset );

	csx = w.csx - m;
	csy = w.csy - m;
	
	n_win_move( nii.txtbox.hwnd, 0,0,csx,csy, redraw );


	return;
}

void
n_imageinfo_on_settingchange( HWND hwnd, UINT msg, WPARAM wparam, LPARAM lparam )
{

	static UINT timer_id = 0;


	switch( msg ) {


	case WM_SETTINGCHANGE :

		// [!] : XP or later : this message is sent many times

		// [!] : Win8.1 : SPI_SETNONCLIENTMETRICS will never come

		if ( timer_id == 0 ) { timer_id = n_win_timer_id_get(); }

		n_win_timer_init( hwnd, timer_id, n_project_settingchange_interval() );

	break;


	case WM_TIMER :

		// [!] : Win95 needs to check WPARAM is ID or not

		if ( wparam == 0 ) { break; }

		if ( wparam != timer_id ) { break; }


		n_win_timer_exit( hwnd, timer_id );


		n_project_darkmode();

		n_win_init_background( hwnd );
		n_win_refresh( hwnd, n_posix_true );

		n_win_txtbox_on_settingchange( &nii.txtbox );

		n_imageinfo_resize( hwnd );

	break;


	} // switch


}

void
n_imageinfo_go( n_posix_char *name )
{

	if ( n_string_path_ext_is_same_literal( ".bmp", name ) )
	{
		n_imageinfo_bmp( name, &nii.txtbox );
	} else
	if (
		( n_string_path_ext_is_same_literal( ".cur", name ) )
		||
		( n_string_path_ext_is_same_literal( ".ico", name ) )
	)
	{
		n_imageinfo_curico( name, &nii.txtbox );
	} else
	if ( n_string_path_ext_is_same_literal( ".png", name ) )
	{
		n_imageinfo_png( name, &nii.txtbox );
	}


	n_win_txtbox_refresh( &nii.txtbox, 0 );


	return;
}

LRESULT CALLBACK
n_imageinfo_wndproc( HWND hwnd, UINT msg, WPARAM wparam, LPARAM lparam )
{

	n_imageinfo_on_settingchange( hwnd, msg, wparam, lparam );


	switch( msg ) {


	case WM_CREATE :


		// Global

		n_win_exedir2curdir();

#ifdef _H_NONNON_WIN32_OLE_IDROPTARGET
		n_IDropTarget_init( hwnd );
#endif // _H_NONNON_WIN32_OLE_IDROPTARGET

		n_project_darkmode();
		//n_win_darkmode_onoff = n_posix_true;

		n_win_ime_disable( hwnd );


		n_memory_zero( &nii, sizeof( n_imageinfo ) );


		// Window

		n_win_init_literal( hwnd, "Nonnon Image Info", "", "" );

		{
			int style  = 0;

			style = style | N_WIN_TXTBOX_STYLE_EDITBOX;
			style = style | N_WIN_TXTBOX_STYLE_VSCROLL;
			style = style | N_WIN_TXTBOX_STYLE_STRIPED;

			int option = 0;

			n_win_txtbox_init( &nii.txtbox, hwnd, style, option );
		}


		// Style

		n_project_window_resizable( hwnd );

		nii.txtbox.txt.readonly = n_posix_true;

		nii.hfont = n_win_font_name2hfont
		(
			n_gdi_font_find
			(
				n_posix_literal( "Consolas" ),
				n_posix_literal( "Courier" ),
				n_posix_literal( "FixedSys" )
			),
			0
		);
		n_win_font_set( nii.txtbox.hwnd, nii.hfont, n_posix_true );

		n_win_txtbox_line_add( &nii.txtbox, 0, n_posix_literal( "Drop Here" ) );


		{

			n_posix_char *name = n_win_commandline_new();

			n_imageinfo_go( name );

			n_string_path_free( name );

		}

		// Size

		n_imageinfo_resize( hwnd );


		// Display

		ShowWindow( hwnd, SW_NORMAL );

	break;

	case WM_SIZE :

		n_imageinfo_resize( hwnd );

	break;

	case WM_DROPFILES :
	{

		n_posix_char *name = n_win_dropfiles_multiple_new( hwnd, wparam );

		n_imageinfo_go( name );

		n_string_path_free( name );

	}
	break;


	case WM_CLOSE :

		ShowWindow( hwnd, SW_HIDE );

		n_win_txtbox_exit( &nii.txtbox );

		n_win_font_exit( nii.hfont );

#ifdef _H_NONNON_WIN32_OLE_IDROPTARGET
		n_IDropTarget_exit( hwnd );
#endif // _H_NONNON_WIN32_OLE_IDROPTARGET

		DestroyWindow( hwnd );

	break;

	case WM_DESTROY :

		PostQuitMessage( 0 );

	break;


	} // switch


	{
		int ret = n_win_txtbox_proc( hwnd, msg, wparam, lparam, &nii.txtbox );
		if ( ret ) { return ret; }
	}


	return DefWindowProc( hwnd, msg, wparam, lparam );
}

#ifndef NONNON_APPS

int WINAPI
WinMain( HINSTANCE hinst, HINSTANCE hprv, LPSTR cmd, int show )
{
	return n_win_main( NULL, n_imageinfo_wndproc );
}

#endif // #ifndef NONNON_APPS

