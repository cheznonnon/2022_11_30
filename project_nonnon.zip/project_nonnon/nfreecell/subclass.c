// Nonnon Freecell
// copyright (c) nonnon all rights reserved
// License : GPL http://www.gnu.org/copyleft/gpl.html




#include "../nonnon/win32/explorer.c"




LRESULT CALLBACK
n_freecell_on_event( HWND hwnd, UINT msg, WPARAM wparam, LPARAM lparam )
{

	switch( msg ) {


	case WM_SETTINGCHANGE :

		// [!] : XP or later : this message is sent many times

		SetTimer( hwnd, N_FREECELL_TIMER_ID_STYLE, n_project_settingchange_interval(), NULL );

	break;

	case WM_TIMER :

		if ( wparam == 0 ) { break; }

		if ( wparam == N_FREECELL_TIMER_ID_STYLE )
		{

			n_win_timer_exit( hwnd, N_FREECELL_TIMER_ID_STYLE );

			extern void n_freecell_style_change( n_freecell* );
			n_freecell_style_change( &freecell );

			extern void n_freecell_flush_background( n_freecell* );
			n_freecell_flush_background( &freecell );

			extern void n_freecell_redraw( n_freecell* );
			n_freecell_redraw( &freecell );

			n_game_refresh_on();
			n_game_loop();

			n_win_message_send( game.hwnd, WM_PAINT, 0,0 );

		}

	break;


	case WM_DISPLAYCHANGE :
	{

		n_bool is_maximized = IsZoomed( game.hwnd );
		ShowWindow( game.hwnd, SW_NORMAL );


		extern void n_freecell_style_change( n_freecell* );
		n_freecell_style_change( &freecell );


		game.sx = freecell.cardgen.csx;
		game.sy = freecell.cardgen.csy;

		n_win_set( game.hwnd, NULL, game.sx,game.sy, N_WIN_SET_CENTERING );

		n_game_bmp_init();


		int i = 0;
		n_posix_loop
		{

			n_bmp_free( &freecell.shadow_bmp_cache[ i ] );

			i++;
			if ( i >= N_FREECELL_SHADOW_COUNT ) { break; }
		}


		extern void n_freecell_flush_background( n_freecell* );
		n_freecell_flush_background( &freecell );

		extern void n_freecell_reset( n_freecell*, n_bool );
		n_freecell_reset( &freecell, n_false );

		extern void n_freecell_reposition( n_freecell* );
		n_freecell_reposition( &freecell );

		extern void n_freecell_redraw( n_freecell* );
		n_freecell_redraw( &freecell );


		if ( is_maximized )
		{
			ShowWindow( game.hwnd, SW_MAXIMIZE );
		}


		n_game_refresh_on();
		n_game_loop();

		n_win_message_send( game.hwnd, WM_PAINT, 0,0 );

	}
	break;

/*
	// [x] : WM_MOUSEMOVE : stop to respond sometimes

	case WM_LBUTTONDBLCLK :
	{
		extern void n_freecell_input_doubleclick( n_freecell* );
		n_freecell_input_doubleclick( &freecell );
	}
	break;


	case WM_LBUTTONUP :
	{
		ReleaseCapture();

		extern void n_freecell_input( n_freecell* );
		n_freecell_input( &freecell );
	}
	break;

	case WM_LBUTTONDOWN :
	{
		SetCapture( game.hwnd );

		extern void n_freecell_input( n_freecell* );
		n_freecell_input( &freecell );
	}
	break;

	case WM_MOUSEMOVE :
	{
		extern void n_freecell_input( n_freecell* );
		n_freecell_input( &freecell );
	}
	break;
*/

	case WM_COMMAND :

		if ( (HWND) lparam == freecell.simplemenu.hwnd )
		{
			if ( wparam == N_WIN_SIMPLEMENU_WPARAM_REARRANGE )
			{

				//

			} else
			if ( wparam == 0 )
			{
//n_game_debug_count();
				extern void n_freecell_replay( n_freecell* );
				n_freecell_replay( &freecell );

			} else
			if ( wparam == 2 )
			{

				extern void n_freecell_newgame( n_freecell* );
				n_freecell_newgame( &freecell );

			}// else
		}

	break;

	case WM_KEYDOWN :

		if ( wparam == VK_F12 )
		{
			extern void n_freecell_debug( n_freecell* );
			n_freecell_debug( &freecell );
		}

	break;


	case WM_GETMINMAXINFO :

		n_win_minsize_proc( hwnd,msg,wparam,lparam, freecell.cardgen.csx_min, freecell.cardgen.csy_min );

	break;


	} // switch()


	n_win_simplemenu_proc( hwnd, msg, &wparam, &lparam, NULL );


	return DefWindowProc( hwnd, msg, wparam, lparam );
}

void
n_freecell_menu_init( n_freecell *p )
{

	n_win_simplemenu_init( &p->simplemenu );

	n_win_simplemenu_set( &p->simplemenu, 0, NULL, n_posix_literal( "[ ]Replay"   ), NULL );
	n_win_simplemenu_set( &p->simplemenu, 1, NULL, n_posix_literal( "[-]"         ), NULL );
	n_win_simplemenu_set( &p->simplemenu, 2, NULL, n_posix_literal( "[ ]New Game" ), NULL );


	n_win_titlemenu_init_main( &p->titlemenu, game.hwnd, &p->simplemenu );


	return;
}

LRESULT CALLBACK
n_freecell_on_close( HWND hwnd, UINT msg, WPARAM wparam, LPARAM lparam )
{

	n_win_titlemenu_exit( &freecell.titlemenu );

	n_win_simplemenu_exit( &freecell.simplemenu );


	return 0;
}

