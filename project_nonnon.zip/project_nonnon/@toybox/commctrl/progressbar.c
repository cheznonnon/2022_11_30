



// link is needed : -lcomctl32




#include "../../nonnon/win32/win.c"

#include "../../nonnon/project/macro.c"


#include <commctrl.h>




void
n_win_progressbar_gui( HWND hwnd_parent, HWND *hgui )
{

	HWND h;


	if ( hgui == NULL ) { return; }


	InitCommonControls();


	h = CreateWindowEx(
		0,
		"msctls_progress32",
		"",
		WS_CHILD | WS_VISIBLE | PBS_SMOOTH,
		0,0, 0,0,
		hwnd_parent,
		(HMENU) NULL,
		GetModuleHandle( NULL ),
		NULL );

	n_win_message_send( h, PBM_SETSTEP, 1, 0 );

/*

	n_win_message_send( h, PBM_SETRANGE, 0, MAKELPARAM( 0, 100 ) );
	n_win_message_send( h, PBM_SETPOS, percent, 0 );
	n_win_message_send( h, PBM_SETBKCOLOR,  0, RGB( 0,100,150 ) );
	n_win_message_send( h, PBM_SETBARCOLOR, 0, RGB( 0,150,200 ) );

*/

	(*hgui) = h;


	return;
}


LRESULT CALLBACK
WndProc( HWND hwnd, UINT msg, WPARAM wparam, LPARAM lparam )
{

	static HWND hgui;

	static int  x =  0;
	static int sx = 20;


	switch( msg ) {


	case WM_CREATE :


		SetTimer( hwnd, 0, 33, NULL );


		n_win_progressbar_gui( hwnd, &hgui );


		n_win_init( hwnd, "Nonnon", "", "" );

		n_win_style_new( hwnd, WS_OVERLAPPEDWINDOW );


		n_win_set( hwnd, NULL, 200,200, N_WIN_SET_CENTERING );


		n_win_move_simple( hgui, 0,0,200,sx, n_true );


		ShowWindow( hwnd, SW_NORMAL );

	break;


	case WM_SIZE :

		sx = LOWORD( lparam );
		n_win_move_simple( hgui, 0,0, sx,20, n_false );

	break;


	case WM_TIMER :

		// [!] : Win95 needs to check WPARAM is ID or not

		if ( wparam == 0 )
		{

			x++;
			if ( x > 120 )
			{
				x = 0;
			}

			n_win_message_send( hgui, PBM_SETPOS, x, 0 );

		}

	break;


	case WM_CLOSE :

		ShowWindow( hwnd, SW_HIDE );

		n_win_timer_exit( hwnd, 0 );

		DestroyWindow( hwnd );

	break;

	case WM_DESTROY :

		PostQuitMessage( 0 );

	break;


	} // switch


	return DefWindowProc( hwnd, msg, wparam, lparam );
}

int WINAPI
WinMain( HINSTANCE hinst, HINSTANCE prv_hinst, LPSTR cmd, int show )
{
	return n_win_main( NULL, WndProc );
}

