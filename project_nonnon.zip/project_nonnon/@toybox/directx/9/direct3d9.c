// Nonnon DirectX
// copyright (c) nonnon all rights reserved
// License : GPL http://www.gnu.org/copyleft/gpl.html


// Link : -ld3d9




#include <d3d9.h>




#include "../../../nonnon/neutral/bmp/all.c"




#define N_D3D9_VERTEX ( D3DFVF_XYZRHW | D3DFVF_DIFFUSE )




static HRESULT hr;

static IDirect3D9             *n_d3d9_IDirect3D9             = NULL;
static IDirect3DDevice9       *n_d3d9_IDirect3DDevice9       = NULL;
static IDirect3DVertexBuffer9 *n_d3d9_IDirect3DVertexBuffer9 = NULL;

static D3DPRESENT_PARAMETERS   n_d3d9_D3DPRESENT_PARAMETERS;




typedef struct {

	float x, y, z, rhw;
	DWORD color;

} n_d3d9_vertex;

static n_d3d9_vertex *n_d3d9_vertices = NULL;




#include "./direct3d9_bitmap.c"




void
n_d3d9_clear( COLORREF color )
{

	if( n_d3d9_IDirect3DDevice9 == NULL ) { return; }


	IDirect3DDevice9_Clear
	(
		n_d3d9_IDirect3DDevice9,
		0,
		NULL,
		D3DCLEAR_TARGET,
		D3DCOLOR_XRGB( GetRValue( color ), GetGValue( color ), GetBValue( color ) ),
		1.0f, 0
	);


	return;
}

n_posix_bool
n_d3d9_is_on( void )
{
	return ( ( n_d3d9_IDirect3D9 != NULL )&&( n_d3d9_IDirect3DDevice9 != NULL ) );
}

n_posix_bool
n_d3d9_init( HWND hwnd )
{

	// [!] : "hwnd" need to be top-level window


	CoInitialize( NULL );


	if ( n_d3d9_IDirect3D9 == NULL )
	{
		n_d3d9_IDirect3D9 = Direct3DCreate9( D3D_SDK_VERSION );
		if ( n_d3d9_IDirect3D9 == NULL )
		{
n_posix_debug_literal( " Direct3DCreate9() " );
			return n_posix_true;
		}
	}


	ZeroMemory( &n_d3d9_D3DPRESENT_PARAMETERS, sizeof( D3DPRESENT_PARAMETERS ) );

	//n_d3d9_D3DPRESENT_PARAMETERS.BackBufferWidth      = 100;
	//n_d3d9_D3DPRESENT_PARAMETERS.BackBufferHeight     = 100;
	n_d3d9_D3DPRESENT_PARAMETERS.hDeviceWindow        = hwnd;
	n_d3d9_D3DPRESENT_PARAMETERS.Windowed             = TRUE;
	n_d3d9_D3DPRESENT_PARAMETERS.SwapEffect           = D3DSWAPEFFECT_DISCARD;
	n_d3d9_D3DPRESENT_PARAMETERS.BackBufferFormat     = D3DFMT_UNKNOWN;
	n_d3d9_D3DPRESENT_PARAMETERS.Flags                = 0;//D3DPRESENTFLAG_DEVICECLIP;
	n_d3d9_D3DPRESENT_PARAMETERS.PresentationInterval = D3DPRESENT_INTERVAL_DEFAULT;

	if( n_d3d9_IDirect3DDevice9 != NULL )
	{
		IDirect3DDevice9_Release( n_d3d9_IDirect3DDevice9 );
		n_d3d9_IDirect3DDevice9 = NULL;
	}

	hr = IDirect3D9_CreateDevice
	(
		n_d3d9_IDirect3D9,
		D3DADAPTER_DEFAULT,
		D3DDEVTYPE_HAL,
		hwnd,
		D3DCREATE_HARDWARE_VERTEXPROCESSING,
		&n_d3d9_D3DPRESENT_PARAMETERS,
		&n_d3d9_IDirect3DDevice9
	);
	if ( FAILED( hr ) )
	{
n_posix_debug_literal( "IIDirect3D9_CreateDevice()" );

		return n_posix_true;
	}

/*
n_win_hwndprintf_literal
(
	hwnd,
	"%d %d",
	n_d3d9_D3DPRESENT_PARAMETERS.BackBufferWidth,
	n_d3d9_D3DPRESENT_PARAMETERS.BackBufferHeight
);
*/


	return n_posix_false;
}

void
n_d3d9_exit( void )
{

	n_d3d9_bitmap_exit();


	if( n_d3d9_IDirect3DDevice9 != NULL )
	{
		IDirect3DDevice9_Release( n_d3d9_IDirect3DDevice9 );
		n_d3d9_IDirect3DDevice9 = NULL;
	}

	if( n_d3d9_IDirect3D9 != NULL )
	{
		IDirect3D9_Release( n_d3d9_IDirect3D9 );
		n_d3d9_IDirect3D9 = NULL;
	}


	CoUninitialize();


	return;
}

