// Nonnon Applet
// copyright (c) nonnon all rights reserved
// License : GPL http://www.gnu.org/copyleft/gpl.html


// PROBLEM : if fail, catastrophe!




#include <windows.h>




// internal
BOOL CALLBACK
n_taskbar_first_callback( HWND hwnd, LPARAM lparam )
{

	long tmp;

	char str[ MAX_PATH ]; ZeroMemory( str, MAX_PATH );
	GetClassName( hwnd, str, MAX_PATH );


	if (
		( hwnd != (HWND) lparam )
		&&
		( IsWindow( hwnd ) )
		&&
		( IsWindowVisible( hwnd ) )
		&&
		( 0 != lstrcmp( str,       "Progman" ) )
		&&
		( 0 != lstrcmp( str, "Shell_TrayWnd" ) )
	)
	{

		if ( IsIconic( hwnd ) ) { tmp = SW_MINIMIZE; } else
		if ( IsZoomed( hwnd ) ) { tmp = SW_MAXIMIZE; } else { tmp = SW_NORMAL; }

		SetWindowPos
		(
			hwnd,
			NULL,
			0,0, 0,0,
			SWP_NOMOVE     | SWP_NOSIZE     | SWP_NOZORDER       |
			SWP_NOREDRAW   | SWP_HIDEWINDOW | SWP_NOSENDCHANGING |
			SWP_NOCOPYBITS | SWP_DEFERERASE | SWP_ASYNCWINDOWPOS
		);

		//ShowWindow( hwnd, SW_HIDE );
		ShowWindowAsync( hwnd, tmp );

	}


	return TRUE;
}

void
n_taskbar_first( HWND hwnd )
{

	// at WM_CREATE : after ShowWindow()


	EnumWindows( n_taskbar_first_callback, (LPARAM) hwnd );


	return;
}

