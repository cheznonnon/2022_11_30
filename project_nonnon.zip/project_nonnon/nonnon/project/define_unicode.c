// Project Nonnon 
// copyright (c) nonnon all rights reserved
// License : GPL http://www.gnu.org/copyleft/gpl.html




#ifndef _H_NONNON_PROJECT_DEFINE_UNICODE
#define _H_NONNON_PROJECT_DEFINE_UNICODE


// [Mechanism]
//
//	1 : include this first
//	2 : comment-out "#define NONNON_UNICODE" for ANSI build, else Unicode build


#define NONNON_UNICODE


#ifdef NONNON_UNICODE

#define _UNICODE
#define  UNICODE

#endif // #ifdef NONNON_UNICODE


#endif // _H_NONNON_PROJECT_DEFINE_UNICODE

