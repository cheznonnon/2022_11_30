// Nonnon Win32
// copyright (c) nonnon all rights reserved
// License : GPL http://www.gnu.org/copyleft/gpl.html




#ifndef _H_NONNON_WIN32_WIN_DWM
#define _H_NONNON_WIN32_WIN_DWM




#include "../registry.c"

#include "../gdi/color.c"
#include "../gdi/doublebuffer_32bpp.c"


#include "./darkmode.c"




n_posix_bool
n_win_dwm_is_on( void )
{

	n_posix_bool ret = n_posix_false;


	// [!] : for compatibility layer support

	if ( n_posix_false == n_sysinfo_version_vista_or_later() ) { return ret; }


	HMODULE hmod = LoadLibrary( n_posix_literal( "dwmapi.dll" ) );
	if ( hmod == NULL ) { return ret; }

	FARPROC func = GetProcAddress( hmod, "DwmIsCompositionEnabled" );
	if ( func != NULL )
	{
		if ( S_OK != func( &ret ) ) { ret = n_posix_false; }
	}

	FreeLibrary( hmod );

/*
	HMODULE hmod = LoadLibrary( n_posix_literal( "UxTheme.dll" ) );
	if ( hmod == NULL ) { return ret; }

	FARPROC func = GetProcAddress( hmod, "IsCompositionActive" );
	if ( func != NULL )
	{
		ret = func();
	}

	FreeLibrary( hmod );
*/

	return ret;
}

n_posix_bool
n_win_dwm_aeroglass_is_on( void )
{

	n_posix_bool ret = n_posix_false;


	if (
		( n_win_dwm_is_on() )
		&&
		( n_posix_false == n_sysinfo_version_8_or_later() )
	)
	{
		ret = n_posix_true;
	}


	return ret;
}

#define n_win_dwm_transparent_on(  hwnd ) n_win_dwm_transparent_on_partial( hwnd, -1,-1,-1,-1 )
#define n_win_dwm_transparent_off( hwnd ) n_win_dwm_transparent_on_partial( hwnd,  0, 0, 0, 0 )

void
n_win_dwm_transparent_on_partial( HWND hwnd, int left, int top, int right, int bottom )
{

	// [Mechanism]
	//
	//	only black color will be handled as transparent
	//	NULL_BRUSH is meaningless
	//	UxTheme/Visual Style API is needed for alpha-blending
	//	almost controls are not supported this feature
	//
	//	you can use these techniques
	//
	//	[ WM_CREATE ]
	//	SetClassLong( hwnd, GCL_HBRBACKGROUND, (LONG) 0 );
	//
	//	[ WM_ERASEBKGND ]
	//	return TRUE;
	//
	//	[ WM_PAINT ]
	//	CreateSolidBrush( RGB( 0,0,0 ) );
	//
	//	[ WM_SETTINGCHANGE ]
	//	call this module again


	HMODULE hmod = LoadLibrary( n_posix_literal( "dwmapi.dll" ) );
	if ( hmod == NULL ) { return; }


	// [!] : uxtheme.h

	typedef struct _MARGINS {

		int cxLeftWidth;
		int cxRightWidth;
		int cyTopHeight;
	  	int cyBottomHeight;

	} MARGINS, *PMARGINS;


	FARPROC func = GetProcAddress( hmod, "DwmExtendFrameIntoClientArea" );
	if ( func != NULL )
	{

		MARGINS ms = { left, right, top, bottom };

		func( hwnd, &ms );

	}


	FreeLibrary( hmod );


	return;
}

u32
n_win_dwm_windowcolor( void )
{

	u32 fallback = n_gdi_systemcolor( COLOR_ACTIVECAPTION );
	u32 color    = fallback;


	if ( n_posix_false == n_win_dwm_is_on() ) { return color; }


	// [x] : DwmGetColorizationColor() returns a how-to-use-this value

	if ( n_sysinfo_version_10_or_later() )
	{

		n_posix_char *subkey  = n_posix_literal( "Software\\Microsoft\\Windows\\DWM" );
		n_posix_char *section = n_posix_literal( "ColorPrevalence" );
		u32           onoff   = 0;

		DWORD ret = n_registry_read( HKEY_CURRENT_USER, subkey, section, &onoff, sizeof( u32 ) );
		if ( ( ret != ERROR_SUCCESS )||( onoff == 0 ) )
		{

			section = n_posix_literal( "ColorizationColor" );

			DWORD ret = n_registry_read( HKEY_CURRENT_USER, subkey, section, &color, sizeof( u32 ) );
			if ( ret != ERROR_SUCCESS ) { color = fallback; }

		} else {

			section = n_posix_literal( "AccentColor" );

			DWORD ret = n_registry_read( HKEY_CURRENT_USER, subkey, section, &color, sizeof( u32 ) );
			if ( ret != ERROR_SUCCESS )
			{

				color = fallback;

			} else {

				// [!] : format : ABGR

				int a = n_bmp_a( color );
				int r = n_bmp_r( color );
				int g = n_bmp_g( color );
				int b = n_bmp_b( color );

				color = n_bmp_argb( a,b,g,r );

			}
//if ( color != 0x00cca329 ) { n_posix_debug_literal( " ! " ); }
		}

	} else {

		n_posix_char *subkey  = n_posix_literal( "Software\\Microsoft\\Windows\\DWM" );
		n_posix_char *section = n_posix_literal( "ColorizationColor" );

		DWORD ret = n_registry_read( HKEY_CURRENT_USER, subkey, section, &color, sizeof( u32 ) );
		if ( ret != ERROR_SUCCESS ) { color = fallback; }

	}


	// [x] : alpha is used in many cases

	return n_bmp_alpha_visible_pixel( color );
}

u32
n_win_dwm_windowcolor_arranged( void )
{

	u32 color = n_win_dwm_windowcolor();

/*
	int r = n_bmp_r( color );
	int g = n_bmp_g( color );
	int b = n_bmp_b( color );

	if ( ( r == g )&&( g == b ) )
	{
		if ( r >= 222 ) { color = n_bmp_rgb( 0,200,255 ); }
	}
*/

	color = n_bmp_lightness_replace_pixel( color, 128 );


	return color;
}

u32
n_win_dwm_windowcolor_ui( HWND hwnd_window )
{

	// [x] : don't use in WM_CREATE

	HWND hwnd_desktop = 0;

	HDC hdc = GetDC( hwnd_desktop );

	RECT rect; GetWindowRect( hwnd_window, &rect );

	n_type_gfx border_x = GetSystemMetrics( SM_CXBORDER ) + 1;
	n_type_gfx border_y = GetSystemMetrics( SM_CYBORDER ) + 1;

	n_type_gfx x = rect.left + border_x;
	n_type_gfx y = rect.top  + border_y;

	u32 color = 0;

	if ( IsWindowVisible( hwnd_window ) )
	{
		color = n_bmp_colorref2argb( GetPixel( hdc, x, y ) );
//color = n_bmp_rgb(n_random_range(255),n_random_range(255),n_random_range(255));
	}

	ReleaseDC( hwnd_desktop, hdc );


	return color;
}

n_posix_bool
n_win_dwm_is_accent_color_used( void )
{

	u32 onoff = (u32) n_posix_true;


	if ( n_win_dwm_is_on() )
	{

		n_posix_char *subkey  = n_posix_literal( "Software\\Microsoft\\Windows\\DWM" );
		n_posix_char *section = n_posix_literal( "ColorPrevalence" );

		DWORD ret = n_registry_read( HKEY_CURRENT_USER, subkey, section, &onoff, sizeof( u32 ) );

		if ( ret != ERROR_SUCCESS ) { onoff = n_posix_true; }

	}


	return onoff;
}

n_posix_bool
n_win_dwm_is_opaque( void )
{

	u32 onoff = (u32) n_posix_true;


	if ( n_win_dwm_is_on() )
	{

		n_posix_char *subkey  = n_posix_literal( "Software\\Microsoft\\Windows\\DWM" );
		n_posix_char *section = n_posix_literal( "ColorizationOpaqueBlend" );

		DWORD ret = n_registry_read( HKEY_CURRENT_USER, subkey, section, &onoff, sizeof( u32 ) );

		if ( ret != ERROR_SUCCESS ) { onoff = n_posix_true; }

	}


	return onoff;
}


#endif // _H_NONNON_WIN32_WIN_DWM

