// Nonnon Win32
// copyright (c) nonnon all rights reserved
// License : GPL http://www.gnu.org/copyleft/gpl.html




#ifndef _H_NONNON_WIN32_WIN_TIMER
#define _H_NONNON_WIN32_WIN_TIMER




static UINT n_win_timer_id = 0;

UINT
n_win_timer_id_get( void )
{
	n_win_timer_id++;
	return n_win_timer_id;
}




void
n_win_timer_init( HWND hwnd, UINT id, DWORD msec )
{

	// [!] : prevent handle leak
	KillTimer( hwnd, id );

	SetTimer( hwnd, id, msec, NULL );

	return;
}

void
n_win_timer_exit( HWND hwnd, UINT id )
{

	KillTimer( hwnd, id );

	return;
}




#endif // _H_NONNON_WIN32_WIN_TIMER

