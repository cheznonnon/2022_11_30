// Nonnon Nyaurism
// copyright (c) nonnon all rights reserved
// License : GPL http://www.gnu.org/copyleft/gpl.html




#include "../nonnon/neutral/wav.c"
#include "../nonnon/neutral/wav/all.c"

#include "../nonnon/win32/win.c"
#include "../nonnon/win32/win_button.c"
#include "../nonnon/win32/win_combobox.c"
#include "../nonnon/win32/win_groupbox.c"
#include "../nonnon/win32/win_progressbar.c"


#include "../nonnon/project/macro.c"




#define H_GROUP       n_nyaurism_formatter_hgui[ 0 ]
#define H_LBL_BYTE    n_nyaurism_formatter_hgui[ 1 ]
#define H_LBL_CHANNEL n_nyaurism_formatter_hgui[ 2 ]
#define H_LBL_BIT     n_nyaurism_formatter_hgui[ 3 ]
#define H_LBL_RATE    n_nyaurism_formatter_hgui[ 4 ]
#define GUI_MAX                                  5

#define H_OK          n_nyaurism_formatter_hbtn[ 0 ]
#define H_CANCEL      n_nyaurism_formatter_hbtn[ 1 ]
#define BTN_MAX                                  2

#define H_CMB_CHANNEL n_nyaurism_formatter_combo[ 0 ]
#define H_CMB_BIT     n_nyaurism_formatter_combo[ 1 ]
#define H_CMB_RATE    n_nyaurism_formatter_combo[ 2 ]

#define MSG_TITLE           " Formatter "

#define MSG_CHANNEL         "Channel"
#define MSG_CHANNEL_MONO    "Mono"
#define MSG_CHANNEL_STEREO  "Stereo"

#define MSG_BIT             "Bit"
#define MSG_BIT_8           "8bit"
#define MSG_BIT_16          "16bit"

#define MSG_RATE            "Rate"
#define MSG_RATE_11         "11k : 11025"
#define MSG_RATE_22         "22k : 22050"
#define MSG_RATE_44         "44k : 44100"


static HWND         n_nyaurism_formatter_hgui[ GUI_MAX ];
static n_win_button n_nyaurism_formatter_hbtn[ BTN_MAX ];
static n_win_combo  n_nyaurism_formatter_combo[ 3 ];

static n_bool       n_nyaurism_formatter_onoff = n_false;




// internal
void
n_nyaurism_formatter_parameter( HWND hwnd, int *ret_channel, int *ret_bit, int *ret_rate )
{

	n_posix_char *str;


	str = n_win_combo_selection_get( &H_CMB_CHANNEL );

	int channel = 0;
	if ( n_string_is_same_literal( MSG_CHANNEL_MONO,   str ) ) { channel = 1; } else
	if ( n_string_is_same_literal( MSG_CHANNEL_STEREO, str ) ) { channel = 2; }


	str = n_win_combo_selection_get( &H_CMB_BIT );

	int bit = 0;
	if ( n_string_is_same_literal( MSG_BIT_8,  str ) ) { bit =  8; } else
	if ( n_string_is_same_literal( MSG_BIT_16, str ) ) { bit = 16; }


	str = n_win_combo_selection_get( &H_CMB_RATE );

	int rate = 0;
	if ( n_string_is_same_literal( MSG_RATE_11, str ) ) { rate = 11; } else
	if ( n_string_is_same_literal( MSG_RATE_22, str ) ) { rate = 22; } else
	if ( n_string_is_same_literal( MSG_RATE_44, str ) ) { rate = 44; }


	if ( ret_channel != NULL ) { (*ret_channel) = channel; }
	if ( ret_bit     != NULL ) { (*ret_bit    ) =     bit; }
	if ( ret_rate    != NULL ) { (*ret_rate   ) =    rate; }


	return;
}

void
n_nyaurism_formatter_bytecount( HWND hwnd )
{

	int c,b,r; n_nyaurism_formatter_parameter( hwnd, &c, &b, &r );
	b /= 8;

	int sample = N_WAV_COUNT( &n_nyaurism_wav ) / 44;

	n_posix_char str[ N_PATH_MAX ];
	n_posix_sprintf_literal( str, "%d byte", ( sample * c * b * r ) + 44 );

	n_win_text_set( H_LBL_BYTE, str );


	return;
}

void
n_nyaurism_formatter_resize( HWND hwnd )
{

	const n_bool redraw = n_true;


	n_type_gfx ctl,ico,m; n_win_stdsize( hwnd, &ctl, &ico, &m );


	n_win w; n_win_set( hwnd, &w, -1,-1, N_WIN_SET_CALCONLY );

	n_type_gfx  unit_x = n_posix_min_n_type_gfx( w.csx / 2, ico * 6 );
	n_type_gfx  unit_y = ctl * 8;

	n_type_gfx start_x = ( w.csx - unit_x ) / 2;
	n_type_gfx start_y = ( w.csy - unit_y ) / 2;

	{

		n_type_gfx  x = start_x - ( ico * 1 );
		n_type_gfx  y = start_y;
		n_type_gfx sx =  unit_x + ( ico * 2 );
		n_type_gfx sy =  unit_y;

		n_win_move( H_GROUP, x,y,sx,sy, redraw );

	}

	{

		n_type_gfx cmb    = 10;
		n_type_gfx half_x = unit_x / 2;

		n_type_gfx x = start_x;
		n_type_gfx y = start_y + ctl;

		n_win_move       (  H_LBL_BYTE,    x,y, unit_x,ctl, redraw ); y += ctl;
		n_win_move       (  H_LBL_CHANNEL, x,y, half_x,ctl, redraw ); x += half_x;
		n_win_combo_move ( &H_CMB_CHANNEL, x,y, half_x,cmb, redraw ); x = start_x; y += ctl;
		n_win_move       (  H_LBL_BIT,     x,y, half_x,ctl, redraw ); x += half_x;
		n_win_combo_move ( &H_CMB_BIT,     x,y, half_x,cmb, redraw ); x = start_x; y += ctl;
		n_win_move       (  H_LBL_RATE,    x,y, half_x,ctl, redraw ); x += half_x;
		n_win_combo_move ( &H_CMB_RATE,    x,y, half_x,cmb, redraw ); x = start_x; y += ctl;
		y += ctl;
		n_win_button_move( &H_OK         , x,y, half_x,ctl, redraw ); x += half_x + 1;
		n_win_button_move( &H_CANCEL     , x,y, half_x,ctl, redraw );

	}


	return;
}

void
n_nyaurism_formatter_show
(
	HWND            hwnd,
	HWND           *hgui, int gui_max,
	n_win_button   *hbtn, int btn_max,
	n_win_scroller *hscr, int scr_max
)
{

	ShowWindow( n_nyaurism_list.hwnd, SW_HIDE );

	int i = 0;
	n_posix_loop
	{

		ShowWindow( hgui[ i ], SW_HIDE );

		i++;
		if ( i >= gui_max ) { break; }
	}

	i = 0;
	n_posix_loop
	{

		ShowWindow( hbtn[ i ].hwnd, SW_HIDE );

		i++;
		if ( i >= btn_max ) { break; }
	}

	i = 0;
	n_posix_loop
	{

		nwscr_show( &hscr[ i ], SW_HIDE );

		i++;
		if ( i >= scr_max ) { break; }
	}


	n_nyaurism_formatter_onoff = n_true;


	//n_win_box( hwnd, NULL, NULL, n_win_darkmode_systemcolor( COLOR_BTNFACE ) );


	// [!] : groupbox needs to be initialized last

	n_win_gui_literal( hwnd, CANVAS,          "", &H_LBL_BYTE    );
	n_win_gui_literal( hwnd, LABEL , MSG_CHANNEL, &H_LBL_CHANNEL );
	n_win_gui_literal( hwnd, LABEL ,     MSG_BIT, &H_LBL_BIT     );
	n_win_gui_literal( hwnd, LABEL ,    MSG_RATE, &H_LBL_RATE    );

	n_win_button_init_literal( &H_OK    , hwnd, "OK"    , PBS_NORMAL ); H_OK.default_onoff = n_true;
	n_win_button_init_literal( &H_CANCEL, hwnd, "Cancel", PBS_NORMAL );

	n_win_combo_zero( &H_CMB_CHANNEL );
	n_win_combo_zero( &H_CMB_BIT     );
	n_win_combo_zero( &H_CMB_RATE    );

	n_win_combo_init( &H_CMB_CHANNEL, hwnd );
	n_win_combo_init( &H_CMB_BIT    , hwnd );
	n_win_combo_init( &H_CMB_RATE   , hwnd );

	n_win_gui_literal( hwnd, CANVAS, MSG_TITLE, &H_GROUP );


	n_win_stdfont_init( n_nyaurism_formatter_hgui, GUI_MAX );


	n_win_flickerfree_win_iconbutton_init( H_OK    .hwnd );
	n_win_flickerfree_win_iconbutton_init( H_CANCEL.hwnd );


	n_txt_set_literal( &H_CMB_CHANNEL.txt, 0, MSG_CHANNEL_MONO   );
	n_txt_set_literal( &H_CMB_CHANNEL.txt, 1, MSG_CHANNEL_STEREO );

	n_txt_set_literal( &H_CMB_BIT.txt    , 0, MSG_BIT_8          );
	n_txt_set_literal( &H_CMB_BIT.txt    , 1, MSG_BIT_16         );

	n_txt_set_literal( &H_CMB_RATE.txt   , 0, MSG_RATE_11        );
	n_txt_set_literal( &H_CMB_RATE.txt   , 1, MSG_RATE_22        );
	n_txt_set_literal( &H_CMB_RATE.txt   , 2, MSG_RATE_44        );

	if ( n_nyaurism_wav.channel == 1 )
	{
		n_win_combo_selection_set( &H_CMB_CHANNEL, 0 );
	} else {
		n_win_combo_selection_set( &H_CMB_CHANNEL, 1 );
	}

	if ( n_nyaurism_wav.bit     == 8 )
	{
		n_win_combo_selection_set( &H_CMB_BIT,     0 );
	} else {
		n_win_combo_selection_set( &H_CMB_BIT,     1 );
	}

	if ( n_nyaurism_wav.rate    == 11 )
	{
		n_win_combo_selection_set( &H_CMB_RATE,    0 );
	} else
	if ( n_nyaurism_wav.rate    == 22 )
	{
		n_win_combo_selection_set( &H_CMB_RATE,    1 );
	} else {
		n_win_combo_selection_set( &H_CMB_RATE,    2 );
	}


	n_nyaurism_formatter_bytecount( hwnd );


	n_nyaurism_formatter_resize( hwnd );


	return;
}

void
n_nyaurism_formatter_hide
(
	HWND            hwnd,
	HWND           *hgui, int gui_max,
	n_win_button   *hbtn, int btn_max,
	n_win_scroller *hscr, int scr_max
)
{

	n_win_flickerfree_win_iconbutton_exit( H_OK    .hwnd );
	n_win_flickerfree_win_iconbutton_exit( H_CANCEL.hwnd );

	n_win_button_exit( &H_OK     );
	n_win_button_exit( &H_CANCEL );


	n_win_combo_silent = n_true;
	n_win_combo_exit( &H_CMB_CHANNEL );

	n_win_combo_silent = n_true;
	n_win_combo_exit( &H_CMB_BIT     );

	n_win_combo_silent = n_true;
	n_win_combo_exit( &H_CMB_RATE    );

	n_win_stdfont_exit( n_nyaurism_formatter_hgui, GUI_MAX );


	ShowWindow( H_LBL_BYTE, SW_HIDE );

	DestroyWindow( H_LBL_BYTE    );
	DestroyWindow( H_LBL_CHANNEL );
	DestroyWindow( H_LBL_BIT     );
	DestroyWindow( H_LBL_RATE    );
	DestroyWindow( H_GROUP       );


	n_nyaurism_formatter_onoff = n_false;


	ShowWindow( n_nyaurism_list.hwnd, SW_SHOW );

	int i = 0;
	n_posix_loop
	{

		ShowWindow( hgui[ i ], SW_SHOW );

		i++;
		if ( i >= gui_max ) { break; }
	}

	i = 0;
	n_posix_loop
	{

		ShowWindow( hbtn[ i ].hwnd, SW_SHOW );

		i++;
		if ( i >= btn_max ) { break; }
	}

	i = 0;
	n_posix_loop
	{

		nwscr_show( &hscr[ i ], SW_SHOW );

		i++;
		if ( i >= scr_max ) { break; }
	}


	n_win_refresh( hwnd, n_true );


	return;
}

// internal
void
n_nyaurism_formatter_go( HWND hwnd )
{

	// [!] : non-breaking

	n_wav save; n_wav_carboncopy( &n_nyaurism_wav, &save );

	int c,b,r; n_nyaurism_formatter_parameter( hwnd, &c, &b, &r );
	//n_wav_reducer( &save, c, b, r );
	save.channel = c;
	save.bit     = b;
	save.rate    = r;

//n_wav_save_literal( &save, "./result.wav" );

	extern void n_nyaurism_save( HWND, n_wav* );
	n_nyaurism_save( hwnd, &save );


	n_wav_free( &save );


	return;
}

LRESULT CALLBACK
n_nyaurism_formatter_wndproc
(
	HWND hwnd, UINT msg, WPARAM wparam, LPARAM lparam,
	HWND           *hgui, int gui_max,
	n_win_button   *hbtn, int btn_max,
	n_win_scroller *hscr, int scr_max
)
{

	static UINT timer_id = 0;


	switch( msg ) {


	case WM_SETTINGCHANGE :

		// [!] : XP or later : this message is sent many times

		// [!] : Win8.1 : SPI_SETNONCLIENTMETRICS will never come

		if ( timer_id == 0 ) { timer_id = n_win_timer_id_get(); }
		n_win_timer_init( hwnd, timer_id, n_project_settingchange_interval() );

	break;


	case WM_TIMER :

		// [!] : Win95 needs to check WPARAM is ID or not

		if ( wparam == 0 ) { break; }

		if ( wparam != timer_id ) { break; }
		n_win_timer_exit( hwnd, timer_id );


		n_project_darkmode();

		n_win_init_background( hwnd );
		n_win_refresh( hwnd, n_true );

		n_win_stdfont_init( n_nyaurism_formatter_hgui, GUI_MAX );

		n_win_button_on_settingchange( &H_OK     );
		n_win_button_on_settingchange( &H_CANCEL );

		n_win_combo_on_settingchange( &H_CMB_CHANNEL );
		n_win_combo_on_settingchange( &H_CMB_BIT     );
		n_win_combo_on_settingchange( &H_CMB_RATE    );

	break;


	case WM_SIZE :

		n_nyaurism_formatter_resize( hwnd );

	break;


	case WM_NCLBUTTONDOWN :
	case WM_LBUTTONDOWN   :

		//SetFocus( H_OK );

	break;


	case WM_COMMAND :
	{

		HWND h = (HWND) lparam;

		if (
			( h == n_win_combo_hwnd( &H_CMB_CHANNEL ) )
			||
			( h == n_win_combo_hwnd( &H_CMB_BIT     ) )
			||
			( h == n_win_combo_hwnd( &H_CMB_RATE    ) )
		)
		{

			if (
				( wparam == H_CMB_CHANNEL.wparam_selection_changed )
				||
				( wparam == H_CMB_BIT    .wparam_selection_changed )
				||
				( wparam == H_CMB_RATE   .wparam_selection_changed )
			)
			{
				n_nyaurism_formatter_bytecount( hwnd );
			}

		} else
		if ( h == H_OK.hwnd )
		{

			n_nyaurism_formatter_go( hwnd );

			n_nyaurism_formatter_hide( hwnd, hgui, gui_max, hbtn, btn_max, hscr, scr_max );

		} else
		if ( h == H_CANCEL.hwnd )
		{

			n_nyaurism_formatter_hide( hwnd, hgui, gui_max, hbtn, btn_max, hscr, scr_max );

		}

	}
	break;


	case WM_DRAWITEM :
	{

		DRAWITEMSTRUCT *di = (void*) lparam;
		if ( di == NULL ) { break; }

		if ( H_LBL_BYTE != di->hwndItem ) { break; }

//n_win_box( H_LBL_BYTE, NULL, NULL, RGB( 255,0,0 ) );

		if ( n_win_fluent_ui_onoff )
		{
			n_win_fluent_ui_progress( H_LBL_BYTE, -1 );
		} else {
			COLORREF bg = n_win_darkmode_systemcolor( COLOR_BTNFACE );

			n_win_progressbar_proc( hwnd, msg, wparam, lparam, H_LBL_BYTE, EDGE_ETCHED, 0, bg, bg );
		}

	}
	break;



	} // switch


	n_win_group_proc( hwnd, msg, wparam, lparam, H_GROUP );


	n_win_combo_proc( hwnd, msg, &wparam, &lparam, &H_CMB_CHANNEL );
	n_win_combo_proc( hwnd, msg, &wparam, &lparam, &H_CMB_BIT     );
	n_win_combo_proc( hwnd, msg, &wparam, &lparam, &H_CMB_RATE    );

	n_win_button_proc( hwnd, msg, wparam, lparam, &H_OK     );
	n_win_button_proc( hwnd, msg, wparam, lparam, &H_CANCEL );


	return DefWindowProc( hwnd, msg, wparam, lparam );
}


#undef H_GROUP
#undef H_LBL_BYTE
#undef H_LBL_CHANNEL
#undef H_LBL_BIT
#undef H_LBL_RATE
#undef GUI_MAX

#undef H_OK
#undef H_CANCEL
#undef BTN_MAX

#undef H_CMB_CHANNEL
#undef H_CMB_BIT
#undef H_CMB_RATE

#undef MSG_TITLE

#undef MSG_CHANNEL
#undef MSG_CHANNEL_MONO
#undef MSG_CHANNEL_STEREO

#undef MSG_BIT
#undef MSG_BIT_8
#undef MSG_BIT_16

#undef MSG_RATE
#undef MSG_RATE_11
#undef MSG_RATE_22
#undef MSG_RATE_44

