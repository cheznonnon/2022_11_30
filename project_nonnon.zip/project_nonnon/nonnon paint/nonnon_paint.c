// Nonnon Paint
// copyright (c) nonnon all rights reserved
// License : GPL http://www.gnu.org/copyleft/gpl.html




#ifndef NONNON_APPS

#include "../nonnon/project/define_unicode.c"

#endif // #ifndef NONNON_APPS




//#define N_MEMORY_DEBUG




#include "../nonnon/game/timegettime.c"




#include "../nonnon/com/IShellLink.c"


#include "../nonnon/neutral/bmp/all.c"
#include "../nonnon/neutral/curico.c"
#include "../nonnon/neutral/ini.c"
#include "../nonnon/neutral/png.c"
#include "../nonnon/neutral/jpg.c"
#include "../nonnon/win32/wic.c"


// [!] : before "win.c"
#include "../nonnon/win32/ole/IDropTarget.c"


// [!] : before "win_txtbox.c"
//#include "../nonnon/win32/win_inputpopup.c"


#include "../nonnon/win32/gdi/dibsection.c"
#include "../nonnon/win32/gdi/doublebuffer_32bpp.c"

#include "../nonnon/win32/ole/IPicture.c"

#include "../nonnon/win32/clipboard.c"
#include "../nonnon/win32/explorer.c"
#include "../nonnon/win32/resource.c"

#include "../nonnon/win32/win_button.c"
#include "../nonnon/win32/win_checkbox.c"
#include "../nonnon/win32/win_colorpicker.c"
#include "../nonnon/win32/win_scrollbar.c"
#include "../nonnon/win32/win_scroller.c"
#include "../nonnon/win32/win_statusbar_ownerdraw.c"
#include "../nonnon/win32/win_txtbox.c"
#include "../nonnon/win32/win_titlemenu.c"
#include "../nonnon/win32/wintab.c"

#include "../nonnon/game/direct2d.c"


#include "../nonnon/project/macro.c"
#include "../nonnon/project/ini2gdi.c"




#include "__draw.c"


// [!] : Components : application instance

#include "_extern.c"

#include "nonnon_paint_progressbar.c"

#include "nonnon_paint_colorhistory.c"
#include "nonnon_paint_colorsync.c"
#include "nonnon_paint_formatter.c"
#include "nonnon_paint_frame_anim.c"
#include "nonnon_paint_grab_n_drag.c"
//#include "nonnon_paint_grabber.c"
#include "nonnon_paint_ini.c"
#include "nonnon_paint_layer.c"
////#include "nonnon_paint_pen.c"
//#include "nonnon_paint_preview.c"
#include "nonnon_paint_property.c"
//#include "nonnon_paint_resizer.c"
////#include "nonnon_paint_menu.c"
////#include "nonnon_paint_tool.c"
////#include "nonnon_paint_tool_grabber.c"

// [!] : these files use n_bmp global variables

#include "nonnon_paint_grabber.c"
#include "nonnon_paint_preview.c"
#include "nonnon_paint_refresh.c"
#include "nonnon_paint_resizer.c"
#include "nonnon_paint_tweaker.c"
#include "nonnon_paint_printer.c"

// [!] : these files have some dependencies

#include "nonnon_paint_pen.c"
#include "nonnon_paint_menu.c"
#include "nonnon_paint_tool.c"
#include "nonnon_paint_tool_grabber.c"

#include "nonnon_paint_hamburger.c"
#include "nonnon_paint_thumbnail.c"




// internal
void
n_paint_dialog_info( const n_posix_char *str )
{

	EnableWindow( hwnd_tool, n_false );
	EnableWindow( hwnd_layr, n_false );

	n_project_dialog_info( hwnd_main, str );

	EnableWindow( hwnd_tool, n_true );
	EnableWindow( hwnd_layr, n_true );


	return;
}

// internal
n_bool
n_paint_dialog_yesno( const n_posix_char *str )
{

	EnableWindow( hwnd_tool, n_false );
	EnableWindow( hwnd_layr, n_false );

	n_bool ret = n_project_dialog_yesno( hwnd_main, str );

	EnableWindow( hwnd_tool, n_true );
	EnableWindow( hwnd_layr, n_true );


	return ret;
}

void
n_paint_colorpicker( void )
{

	u32 color = n_paint_grabber_colorpicker();


	int a = n_bmp_a( color );
	int r = n_bmp_r( color );
	int g = n_bmp_g( color );
	int b = n_bmp_b( color );

	nwclr_refresh( &cp, a,r,g,b );


	n_paint_colorhistory_add( color );
	n_sync_go( n_paint_sync_wm_synccolor, 0, color );


	return;
}

// internal
void
n_paint_title( void )
{

	// [!] : japanese version of windows
	//
	//	backslash will be yen sign


	n_posix_char *s = n_string_carboncopy( n_paint_bmpname );


	if ( n_paint_format_is_lyr( s ) ) { n_string_path_ext_del( s ); }


	n_string_replace( s, s, N_STRING_BSLASH, N_STRING_SLASH );

	n_posix_char str_sx[ N_STRING_INT2STR_CCH_MAX ]; n_string_int2str( str_sx, N_BMP_SX( n_paint_bmp_data ) );
	n_posix_char str_sy[ N_STRING_INT2STR_CCH_MAX ]; n_string_int2str( str_sy, N_BMP_SY( n_paint_bmp_data ) );

	n_win_hwndprintf_literal
	(
		hwnd_main,
		"%s (%sx%s)",
		s,
		str_sx,
		str_sy
	);


	n_memory_free( s );


	return;
}

// internal
void
n_paint_status( void )
{

	if ( hwnd_main == GetFocus() )
	{

		n_type_gfx x,y;
		n_paint_canvaspos( &x,&y );

		n_posix_char str_x[ N_STRING_INT2STR_CCH_MAX ]; n_string_int2str( str_x, x );
		n_posix_char str_y[ N_STRING_INT2STR_CCH_MAX ]; n_string_int2str( str_y, y );

		n_win_hwndprintf_literal( hwnd_tool, "%s %s", str_x,str_y );

	} else {

		n_win_hwndprintf_literal( hwnd_tool, "%s", N_PAINT_APPNAME_LITERAL );

	}


	return;
}

// internal
void
n_paint_canvaspos( n_type_gfx *ret_x, n_type_gfx *ret_y )
{

	n_type_gfx x,y;

#ifdef _H_NONNON_WIN32_WIN_WINTAB

	if ( ( n_paint_wintab_onoff )&&( n_wintab_is_pressed( &n_paint_wintab ) ) )
	{
//n_win_hwndprintf_literal( hwnd_main, "WinTab : On" );

		POINT pt = { n_wintab_cursor_x( &n_paint_wintab ), GetSystemMetrics( SM_CYSCREEN ) - n_wintab_cursor_y( &n_paint_wintab ) };

		ScreenToClient( hwnd_main, &pt );

		x = pt.x;
		y = pt.y;

	} else

#endif // #ifdef _H_NONNON_WIN32_WIN_WINTAB

	{
//n_win_hwndprintf_literal( hwnd_main, "WinTab : Off" );

		n_win_cursor_position_relative( hwnd_main, &x, &y );

	}

	n_type_gfx msx,msy; n_paint_margin_get( &msx, &msy );
	x -= msx;
	y -= msy;

	x += nwin_main.scrollx;
	y += nwin_main.scrolly;

	n_paint_zoom_canvas2bitmap( &x, &y, NULL, NULL );


	if ( ret_x != NULL ) { (*ret_x) = x; }
	if ( ret_y != NULL ) { (*ret_y) = y; }


	return;
}

n_bool
n_paint_is_innercanvas( void )
{

	n_type_gfx x,y; n_paint_canvaspos( &x,&y );


	return (
		( x >= 0 )&&( y >= 0 )
		&&
		( x < N_BMP_SX( n_paint_bmp_data ) )
		&&
		( y < N_BMP_SX( n_paint_bmp_data ) )
	);
}

// internal
n_bool
n_paint_load( n_posix_char *name, n_bmp *bmp, n_curico *curico )
{

	n_bool ret;


	// Bitmap

	ret = n_bmp_load( bmp, name );

	if ( ret == n_false )
	{
		n_string_path_ext_mod( N_PAINT_EXT_BMP, name );
		return n_false;
	}


	// Icon/Cursor

	ret = n_curico_load( curico,bmp, name );

	if ( ret == n_false )
	{
		if ( curico->type == N_CURICO_TYPE_ICO )
		{
			n_string_path_ext_mod ( N_PAINT_EXT_ICO, name );
		} else {
			n_string_path_ext_mod ( N_PAINT_EXT_CUR, name );
		}

		return n_false;
	}


	// PNG

	ret = n_png_png2bmp( name, bmp );

	if ( ret == n_false )
	{
		n_string_path_ext_mod( N_PAINT_EXT_PNG, name );
		return n_false;
	}


	// Jpeg

	ret = n_jpg_jpg2bmp( name, bmp );

	if ( ret == n_false )
	{
		n_string_path_ext_mod( N_PAINT_EXT_JPG, name );
		return n_false;
	}


	// some formats : via Windows Imaging Component interface

	ret = n_wic_load( name, bmp );

	if ( ret == n_false )
	{
		n_string_path_ext_mod ( N_PAINT_EXT_BMP, name );
		return n_false;
	}


	// GIF and Jpeg : via OLE IPicture Interface

	ret = n_IPicture_load( name, bmp );

	if ( ret == n_false )
	{
		n_string_path_ext_mod ( N_PAINT_EXT_BMP, name );
		return n_false;
	}


	// INI2GDI

	ret = n_ini2gdi_load( name, bmp );

	if ( ret == n_false )
	{
		n_string_path_ext_mod( N_PAINT_EXT_BMP, name );

		return n_false;
	}


	return n_true;
}

// internal
n_posix_char*
n_paint_newname_new( void )
{

	n_posix_char *dir = n_string_path_folder_current_new();
	n_posix_char *tmp = n_string_path_tmpname_new_literal( ".bmp" );
	n_posix_char *ret = n_string_path_make_new( dir, tmp );

	n_string_path_free( dir );
	n_string_path_free( tmp );

	return ret;
}

// internal
void
n_paint_newfile( const n_posix_char *cmdline )
{

	n_type_int    cch  = n_posix_strlen( cmdline ) + n_posix_strlen( N_PAINT_EXT_BMP ) + 2;
	n_posix_char *name = n_string_alloccopy( cch, cmdline );


	if ( n_paint_grabber_newfile( name ) )
	{

		n_string_path_free( name );

		return;
	}

	n_paint_grabber_reset();


	n_paint_bmp_data = &n_paint_layer_data[ 0 ].bmp_data;
	n_paint_bmp_grab = &n_paint_layer_data[ 0 ].bmp_grab;


	if ( n_paint_load( name, n_paint_bmp_data, &n_paint_curico ) )
	{

		n_string_path_free( name );

		if ( n_false == n_string_is_empty( cmdline ) )
		{
			n_paint_dialog_info( n_project_string_error );
		}

		if ( n_paint_bmp_data->ptr == NULL )
		{

			// [Needed] : only at first time

			n_type_gfx sx = N_PAINT_CANVAS_SIZE;
			n_type_gfx sy = N_PAINT_CANVAS_SIZE;

			n_bmp_new_fast( n_paint_bmp_data, sx,sy );
			n_bmp_flush( n_paint_bmp_data, n_bmp_white );

			n_string_path_free( n_paint_bmpname );
			n_paint_bmpname = n_paint_newname_new();

		}

	} else {

		ShowWindow( hwnd_layr, SW_HIDE );
		n_paint_layer_reset();

		n_string_path_free( n_paint_bmpname );
		n_paint_bmpname = name;

	}


	SetFocus( n_win_cursor2hwnd() );


	if ( n_false == n_string_is_same( n_paint_prvname, cmdline ) )
	{
		nwin_main.scrollx = nwin_main.scrolly = 0;

		n_win_scrollbar_reset( &n_paint_hscr );
		n_win_scrollbar_reset( &n_paint_vscr );
	}

	n_string_path_free( n_paint_prvname );
	n_paint_prvname = n_string_path_carboncopy( cmdline );


	n_paint_refresh_all_id( N_PAINT_REFRESH_ID_NEWFILE );

	n_paint_title();

	n_paint_tool_saveicon_refresh( n_true );


	return;
}

n_posix_char*
n_paint_cmdline_new( void )
{

	n_posix_char *cmdline = n_win_commandline_new();
//n_posix_debug_literal( " 1 : %s ", cmdline );


#ifdef NONNON_APPS

		// [Needed] : for Nonnon Apps

		n_string_commandline_option( N_APPS_OPTION_NONNON_PAINT, cmdline );

#endif // #ifdef NONNON_APPS


	n_posix_char *cmdline_new;

	if ( n_string_path_ext_is_same( N_ISHELLLINK_EXT, cmdline ) )
	{
		cmdline_new = n_string_path_new( N_ISHELLLINK_LNK2PATH_CCH_PATH );
		n_IShellLink_lnk2path( cmdline, cmdline_new, NULL, NULL, NULL );
	} else {
		cmdline_new = n_string_path_carboncopy( cmdline );
	}


	n_string_path_free( cmdline );


//n_posix_debug_literal( " 2 : %s ", cmdline_new );
	return cmdline_new;
}

n_posix_char*
n_paint_dropfiles_new( HWND hwnd, WPARAM wparam )
{

	n_posix_char *cmdline = n_win_dropfiles_multiple_new( hwnd, wparam );


	n_posix_char *cmdline_new;

	if ( n_string_path_ext_is_same( N_ISHELLLINK_EXT, cmdline ) )
	{
		cmdline_new = n_string_path_new( N_ISHELLLINK_LNK2PATH_CCH_PATH );
		n_IShellLink_lnk2path( cmdline, cmdline_new, NULL, NULL, NULL );
	} else {
		cmdline_new = n_string_path_carboncopy( cmdline );
	}


	n_string_path_free( cmdline );


	return cmdline_new;
}

LRESULT CALLBACK
n_paint_wndproc( HWND hwnd, UINT msg, WPARAM wparam, LPARAM lparam )
{

	//static int p_tooltype = N_PAINT_TOOL_TYPE_NONE;


	n_paint_xmouse( hwnd, msg );


	switch( msg ) {


	case WM_SETTINGCHANGE :

		n_project_darkmode();

		n_paint_refresh_all();

	break;

	case WM_DISPLAYCHANGE :

		{
			n_win_desktop_size( &n_paint_desktop_sx, &n_paint_desktop_sy );

			n_type_gfx minim = n_posix_min_n_type_gfx( n_paint_desktop_sx, n_paint_desktop_sy );

			n_paint_thumbnail_size = (n_type_gfx) ( (n_type_real) minim * 0.3 );
		}

		n_bmp_free( &n_paint_bmp_thmb );
		n_bmp_free( &n_paint_bmp_name );

		n_paint_refresh_all();
		n_paint_canvas_zoom_bitmap();

	break;


	case WM_CREATE :


		// Commandline #1

		{
			n_posix_char *cmdline = n_paint_cmdline_new();

			if ( n_paint_layer_load_sniffer( cmdline ) )
			{

				if (
					( n_false == n_curico_multi_pack  ( cmdline ) )
					||
					( n_false == n_curico_multi_unpack( cmdline ) )
				)
				{

					n_string_path_free( cmdline );

					n_explorer_refresh( n_false );

					return -1;
				}

			}

			n_string_path_free( cmdline );

		}


		// Initialization

		n_bmp_safemode = n_bmp_safemode_base = n_false;

		n_bmp_transparent_onoff_default = n_false;

		n_win_icon_init_callback = n_project_system_icon_color;


		n_gdi_dibsection_zero( &n_paint_dibsection, &n_paint_bmp_dbuf );

		n_bmp_zero( &n_paint_bmp_thmb );
		n_bmp_zero( &n_paint_bmp_name );
		n_bmp_zero( &n_paint_bmp_scrl );
		n_bmp_zero( &n_paint_bmp_wgrb );

		n_paint_grabber_init();
	
		n_paint_colorhistory_init();

		n_win_colorpicker_zero( &cp );

		n_win_scrollbar_zero( &n_paint_hscr );
		n_win_scrollbar_zero( &n_paint_vscr );

		n_win_desktop_size( &n_paint_desktop_sx, &n_paint_desktop_sy );

		n_bmp_zero( &n_paint_bmp_zoom_i );
		n_bmp_zero( &n_paint_bmp_zoom_o );
		n_paint_canvas_zoom_bitmap();

		n_paint_layer_data = n_memory_new( sizeof( n_paint_layer ) * n_paint_layer_count );
		n_memory_zero( n_paint_layer_data, sizeof( n_paint_layer ) * n_paint_layer_count );

		n_paint_layer_is_mod = n_memory_new( sizeof( n_posix_bool ) * n_paint_layer_count );
		n_memory_padding_int( n_paint_layer_is_mod, n_false, n_paint_layer_count );

		n_paint_layer_init();
		n_paint_bmp_data = &n_paint_layer_data[ 0 ].bmp_data;
		n_paint_bmp_grab = &n_paint_layer_data[ 0 ].bmp_grab;


		// Global

		n_game_timegettime_init();

#ifdef _H_NONNON_WIN32_OLE_IDROPTARGET
		n_IDropTarget_init( hwnd );
#endif // _H_NONNON_WIN32_OLE_IDROPTARGET

		n_project_darkmode();
		//n_win_darkmode_onoff = n_true;

		n_win_ime_disable( hwnd );


		// [!] : 2020 May : disabled again : useless
		n_win_tabletpc_disable( hwnd );


		// [!] : before n_wintab_init()

		n_win_exedir2curdir();
		n_paint_ini_read();


#ifdef _H_NONNON_WIN32_WIN_WINTAB

		n_wintab_zero( &n_paint_wintab );
		if ( n_paint_wintab_onoff ) { n_wintab_init( &n_paint_wintab, hwnd ); }

#endif // #ifdef _H_NONNON_WIN32_WIN_WINTAB


		{
			n_type_gfx minim = n_posix_min_n_type_gfx( n_paint_desktop_sx, n_paint_desktop_sy );

			n_paint_thumbnail_size = (n_type_gfx) ( (n_type_real) minim * 0.3 );
		}


		// [Needed]
		//
		//	don't rely on n_win_gui()/CreateWindow()'s return value

		hwnd_main = hwnd;


		// Window

		n_win_init_literal( hwnd, "", "NONNON_PAINT_0_MAIN", "NONNON_PAINT_PEN" );

		n_win_style_new( hwnd, N_WS_FIXEDWINDOW );
		n_win_sysmenu_disable( hwnd_main, 0,0,1, 0,1, 0, 0 );


		n_win_gui( hwnd_main, WINDOW, n_paint_tool_wndproc , &hwnd_tool );
		n_win_gui( hwnd_main, WINDOW, n_paint_layer_wndproc, &hwnd_layr );
		n_win_gui( hwnd_main, WINDOW, n_paint_thmb_wndproc , &hwnd_thmb );


		{

			int option = 0;

			option |= N_WIN_SCROLLBAR_OPTION_PAGER;
			option |= N_WIN_SCROLLBAR_OPTION_NO_ARROWS;

			n_win_scrollbar_init( &n_paint_hscr, hwnd, N_WIN_SCROLLBAR_LAYOUT_HORIZONTAL, 0, option );
			n_win_scrollbar_init( &n_paint_vscr, hwnd, N_WIN_SCROLLBAR_LAYOUT_VERTICAL  , 0, option );

		}

		n_paint_hscr.color_edge_ul = N_PAINT_CANVAS_COLOR;
		n_paint_hscr.color_edge_ur = N_PAINT_CANVAS_COLOR;
		n_paint_hscr.color_edge_dl = N_PAINT_CANVAS_COLOR;
		n_paint_hscr.color_edge_dr = N_PAINT_CANVAS_COLOR;

		n_paint_vscr.color_edge_ul = N_PAINT_CANVAS_COLOR;
		n_paint_vscr.color_edge_ur = N_PAINT_CANVAS_COLOR;
		n_paint_vscr.color_edge_dl = N_PAINT_CANVAS_COLOR;
		n_paint_vscr.color_edge_dr = N_PAINT_CANVAS_COLOR;

		n_paint_hscr.color_thumb = n_bmp_blend_pixel( N_PAINT_CANVAS_COLOR, n_bmp_white, 0.5 );
		n_paint_vscr.color_thumb = n_bmp_blend_pixel( N_PAINT_CANVAS_COLOR, n_bmp_white, 0.5 );

		n_paint_hscr.color_press = n_bmp_blend_pixel( N_PAINT_CANVAS_COLOR, n_bmp_black, 0.125 );
		n_paint_vscr.color_press = n_bmp_blend_pixel( N_PAINT_CANVAS_COLOR, n_bmp_black, 0.125 );

		n_paint_hscr.color_shaft = n_bmp_blend_pixel( N_PAINT_CANVAS_COLOR, n_bmp_black, 0.25 );
		n_paint_vscr.color_shaft = n_bmp_blend_pixel( N_PAINT_CANVAS_COLOR, n_bmp_black, 0.25 );


		n_win_simplemenu_zero( &n_paint_simplemenu );
		n_win_simplemenu_init( &n_paint_simplemenu );

		n_paint_menu_init();

		n_win_titlemenu_init_main( &n_paint_titlemenu, hwnd, &n_paint_simplemenu );


		// Commandline

		{
			n_posix_char *cmdline = n_paint_cmdline_new();
//n_posix_debug_literal( " %s ", cmdline );

			n_paint_refresh_lock = n_true;

			if ( n_paint_layer_load( cmdline ) )
			{
//n_posix_debug_literal( " Error " );

				n_paint_newfile( cmdline );

				n_paint_layer_grabber_check_enable( n_false );

				n_paint_layer_grabber_uncheck();

			} else {

				n_paint_layer_grabber_check_enable( n_true );

				n_paint_tool_saveicon_refresh( n_false );

				n_paint_title();

			}

			n_paint_refresh_lock = n_false;
			n_paint_refresh_all();


			if ( n_paint_layer_onoff ) { ShowWindowAsync( hwnd_layr, SW_NORMAL ); }


			n_string_path_free( cmdline );

		}


		// Display

//n_posix_debug_literal( "%d", 1 );

		ShowWindowAsync( hwnd_main, SW_NORMAL ); 
		ShowWindowAsync( hwnd_tool, SW_NORMAL );

		n_paint_thumbnail_show();

	break;


	case WM_DROPFILES :
	{

		// [!] : for nonnon_paint/resizer.c

		if ( n_false == IsWindowEnabled( hwnd ) ) { break; }


		if ( grabber ) { break; }


		n_win_cursor_add( NULL, IDC_WAIT );


		n_posix_char *cmdline = n_paint_dropfiles_new( hwnd, wparam );


		n_paint_refresh_lock = n_true;


		n_type_gfx layer_x, layer_y;

		n_win_position_relative( NULL, hwnd_layr, &layer_x, &layer_y );

		nwin_layr.posx = layer_x;
		nwin_layr.posy = layer_y;


		//ShowWindow( hwnd_layr, SW_HIDE );


		if ( n_paint_layer_load( cmdline ) )
		{

			if (
				( n_false == n_curico_multi_pack  ( cmdline ) )
				||
				( n_false == n_curico_multi_unpack( cmdline ) )
			)
			{

				n_string_path_free( cmdline );

				n_explorer_refresh( n_false );

				n_paint_refresh_lock = n_false;

				n_paint_pen_cursor_default( NULL );

				break;
			}

			n_paint_newfile( cmdline );

			n_paint_layer_grabber_check_enable( n_false );

			n_paint_layer_grabber_uncheck();

		} else {

			n_paint_layer_grabber_check_enable( n_true );

			n_paint_tool_saveicon_refresh( n_false );

			n_paint_title();

		}


		n_paint_refresh_lock = n_false;
		n_paint_refresh_all();


		if ( n_paint_layer_onoff ) { ShowWindowAsync( hwnd_layr, SW_NORMAL ); }


		n_paint_thumbnail_refresh();


		n_string_path_free( cmdline );


		n_paint_pen_cursor_default( NULL );

	}
	break;


	case WM_NCLBUTTONDOWN :

		// [Patch] : disable window moving

		if (
			( HTCAPTION == LOWORD( wparam ) )
			&&
			( nwin_main.state == SIZE_MAXIMIZED )
		)
		{
			n_win_simplemenu_hide( &n_paint_simplemenu );

			SetActiveWindow( hwnd );

			return 0;
		}

//n_win_hwndprintf_literal( hwnd, "%d", LOWORD( wparam ) );

	break;


	case WM_SIZE :

		// [!] : for Shortcut(.LNK) with "Maximized Window"

		if ( IsZoomed( hwnd ) ) { ShowWindow( hwnd, SW_NORMAL ); }

	break;


	case WM_ERASEBKGND :

		return n_true;

	break;

	case WM_PAINT :
	{
//n_win_debug_count( hwnd );

		PAINTSTRUCT ps;
		BeginPaint( hwnd, &ps );

		n_win_rect_move( &ps.rcPaint, nwin_main.scrollx, nwin_main.scrolly );

		n_type_gfx fx,fy,tx,ty;
		n_win_rect_expand_range( &ps.rcPaint, &fx, &fy, &tx, &ty );

//n_win_hwndprintf_literal( hwnd, "%d %d %d", ps.fErase, ps.fRestore, ps.fIncUpdate );
//n_win_hwndprintf_literal( hwnd, "%d %d : %d %d %d %d", nwin_main.csx,nwin_main.csy, fx,fy,tx,ty );

		n_paint_zoom_canvas2bitmap( &fx, &fy, &tx, &ty );


		// [!] : WinXP or earlier : prevent tearing

		n_type_gfx msx,msy; n_paint_margin_get( &msx,&msy );

		if ( n_paint_hscr.unit_max <= n_paint_hscr.unit_page )
		{
			fx -= msx * 2;
			tx += msx * 2;
		}

		if ( n_paint_vscr.unit_max <= n_paint_vscr.unit_page )
		{
			fy -= msy * 2;
			ty += msy * 2;
		}


		if ( n_paint_refresh_combine == N_PAINT_REFRESH_NONE )
		{
			n_paint_refresh( ps.hdc, fx,fy,tx,ty, N_PAINT_REFRESH_CLIENT, N_PAINT_REFRESH_ID_WM_PAINT );
		} else {
			n_paint_refresh_window_id( N_PAINT_REFRESH_ID_WM_PAINT );
			n_paint_refresh_combine = N_PAINT_REFRESH_NONE;
		}


		EndPaint( hwnd, &ps );

	}
	break;

	case WM_COMMAND : 
	{

		HWND h = (HWND) lparam;

		if ( h == n_paint_hscr.hwnd )
		{
//n_posix_debug_literal( "" );

			n_type_gfx z = n_paint_zoom_get( zoom );
			if ( n_paint_is_zoom_out( zoom ) ) { z = 1; }

			n_paint_prev_scrollx = nwin_main.scrollx;

			nwin_main.scrollx = (n_type_gfx) wparam;

			if ( nwin_main.scrollx != ( nwin_main.rcsx - nwin_main.csx ) )
			{
				nwin_main.scrollx = nwin_main.scrollx / z * z;
			}

			if ( n_paint_prev_scrollx == nwin_main.scrollx ) { break; }


			n_paint_hscr.unit_pos = nwin_main.scrollx;

			//if ( n_win_scrollbar_hwnd_global != NULL )
			{
				n_paint_refresh_scroll_id( N_PAINT_REFRESH_ID_SCROLL );
			}

		} else

		if ( h == n_paint_vscr.hwnd )
		{

			n_type_gfx z = n_paint_zoom_get( zoom );
			if ( n_paint_is_zoom_out( zoom ) ) { z = 1; }


			n_paint_prev_scrolly = nwin_main.scrolly;

			nwin_main.scrolly = (n_type_gfx) wparam;

//n_win_hwndprintf_literal( hwnd_main, "%d %d", nwin_main.scrolly, nwin_main.rcsy - nwin_main.csy );

			if ( nwin_main.scrolly != ( nwin_main.rcsy - nwin_main.csy ) )
			{
				nwin_main.scrolly = nwin_main.scrolly / z * z;
			}

			if ( n_paint_prev_scrolly == nwin_main.scrolly ) { break; }


			n_paint_vscr.unit_pos = nwin_main.scrolly;

			//if ( n_win_scrollbar_hwnd_global != NULL )
			{
				n_paint_refresh_scroll_id( N_PAINT_REFRESH_ID_SCROLL );
			}

		}// else

	}
	break;


	case WM_CLOSE :

		ShowWindow( hwnd_thmb, SW_HIDE );
		ShowWindow( hwnd_layr, SW_HIDE );
		ShowWindow( hwnd_tool, SW_HIDE );
		ShowWindow( hwnd_main, SW_HIDE );


		n_paint_ini_write();


		n_bmp_free_fast( &n_paint_bmp_zoom_i );
		n_bmp_free_fast( &n_paint_bmp_zoom_o );


		n_gdi_dibsection_exit( &n_paint_dibsection, &n_paint_bmp_dbuf );

		n_bmp_free( &n_paint_bmp_thmb );
		n_bmp_free( &n_paint_bmp_name );
		n_bmp_free( &n_paint_bmp_scrl );
		n_bmp_free( &n_paint_bmp_wgrb );


		n_win_scrollbar_exit( &n_paint_hscr );
		n_win_scrollbar_exit( &n_paint_vscr );


		n_string_path_free( n_paint_bmpname );
		n_string_path_free( n_paint_grbname );
		n_string_path_free( n_paint_prvname );


		n_win_titlemenu_exit( &n_paint_titlemenu );

		n_win_simplemenu_exit( &n_paint_simplemenu );


		n_paint_tool_grabber_exit();
		n_paint_tool_exit();


		n_paint_layer_exit();
		n_memory_free( n_paint_layer_data   );
		n_memory_free( n_paint_layer_is_mod );

		n_paint_layer_name_exit();


		if ( n_paint_resizer_backup_onoff )
		{
			n_bmp_layer_free( n_paint_resizer_backup_layer );
			n_memory_free( n_paint_resizer_backup_layer );
		}


#ifdef _H_NONNON_WIN32_WIN_WINTAB
		n_wintab_exit( &n_paint_wintab );
#endif // #ifdef _H_NONNON_WIN32_WIN_WINTAB


#ifdef _H_NONNON_WIN32_OLE_IDROPTARGET
		n_IDropTarget_exit( hwnd );
#endif // _H_NONNON_WIN32_OLE_IDROPTARGET


		n_game_timegettime_exit();


		DestroyWindow( hwnd );

	break;

	case WM_DESTROY :

		PostQuitMessage( 0 );

	break;


	case WM_RBUTTONUP :

		// [Patch] : GrabNDrag needs this
		//
		//	captured + title bar menu click causes showing a default system menu

		if ( n_paint_grab_n_drag.onoff ) { return 0; }

	break;


	} // switch


#ifdef _H_NONNON_WIN32_WIN_WINTAB
	if ( n_paint_wintab_onoff ) { n_wintab_packet_proc( hwnd, msg, wparam, lparam, &n_paint_wintab ); }
#endif // #ifdef _H_NONNON_WIN32_WIN_WINTAB


	n_paint_grab_n_drag_proc( hwnd, msg, wparam, lparam );
	if ( n_paint_grab_n_drag.onoff ) { return DefWindowProc( hwnd, msg, wparam, lparam ); }


	{
		int ret = n_paint_pen_proc( hwnd, msg, wparam, lparam );
		if ( ret ) { return ret; }
	}

	n_paint_sync_proc( hwnd, msg, wparam, lparam );


	n_paint_hamburger_proc( hwnd, msg, wparam, lparam );


	n_paint_menu_proc( hwnd, msg, &wparam, &lparam );


	n_paint_tool_input_proc( hwnd, msg, wparam, lparam );


	if ( n_paint_pen_start == n_false )
	{
		n_win_scrollbar_proc( hwnd, msg, wparam, lparam, &n_paint_hscr );
		n_win_scrollbar_proc( hwnd, msg, wparam, lparam, &n_paint_vscr );

		n_win_scrollbar_subclass( hwnd, msg, wparam, lparam, &n_paint_hscr );
		n_win_scrollbar_subclass( hwnd, msg, wparam, lparam, &n_paint_vscr );

		n_win_simplemenu_proc( hwnd, msg, &wparam, &lparam, &n_paint_hscr.menu );
		n_win_simplemenu_proc( hwnd, msg, &wparam, &lparam, &n_paint_vscr.menu );
	}


	// [Needed] : after n_win_scrollbar_*()

	{
		int ret = n_paint_grabber_proc( hwnd, msg, wparam, lparam );
		if ( ret ) { return ret; }
	}


	n_paint_thumbnail_proc( hwnd, msg, wparam, lparam );


	return DefWindowProc( hwnd, msg, wparam, lparam );
}

int
n_paint_main( void )
{

#ifdef _H_NONNON_WIN32_GAME_DIRECT2D

	if ( n_project_dwm_is_on() )
	{
		n_direct2d_init();
	}

#endif // #ifdef _H_NONNON_WIN32_GAME_DIRECT2D


	WPARAM ret = n_win_main( NULL, n_paint_wndproc );


#ifdef _H_NONNON_WIN32_GAME_DIRECT2D

	// [x] : don't put this in WndProc()

	if ( n_direct2d_is_on() )
	{
		n_direct2d_exit();
	}
	
#endif // #ifdef _H_NONNON_WIN32_GAME_DIRECT2D


	return (int) ret;
}

#ifndef NONNON_APPS

int WINAPI
WinMain( HINSTANCE hinst, HINSTANCE prv_hinst, LPSTR cmd, int show )
{
	return n_paint_main();
}

#endif // #ifndef NONNON_APPS

