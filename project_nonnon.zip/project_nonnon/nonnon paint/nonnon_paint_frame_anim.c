// Nonnon Paint
// copyright (c) nonnon all rights reserved
// License : GPL http://www.gnu.org/copyleft/gpl.html


// [!] : animated frame




#define N_PAINT_FRAME_ANIM




#define N_PAINT_FRAME_ANIM_DOT_SIZE ( 8 )


#define N_PAINT_FRAME_ANIM_INTERVAL ( 100 )

static n_posix_bool  n_paint_frame_anim_onoff = n_posix_false;
static n_posix_bool  n_paint_frame_anim_lock  = n_posix_false;
static POINT        *n_paint_frame_anim_path  = NULL;
static n_type_int    n_paint_frame_anim_count =    0;
static n_type_int    n_paint_frame_anim_step  =    0;
static UINT          n_paint_frame_anim_timer =    0;
static POINT         n_paint_frame_anim_ctl[ 4 ];




void
n_paint_frame_anim_pos( n_type_gfx *x, n_type_gfx *y )
{

	n_paint_zoom_bitmap2canvas( x, y, NULL, NULL );


	n_type_gfx ox,oy; n_paint_margin_get( &ox, &oy );

	(*x) += ox;
	(*y) += oy;


	(*x) -= nwin_main.scrollx;
	(*y) -= nwin_main.scrolly;


	return;
}

n_type_gfx
n_paint_frame_anim_dot_size( void )
{

	n_type_gfx dot = N_PAINT_FRAME_ANIM_DOT_SIZE;

	n_type_gfx z = n_paint_zoom_get( zoom );
	if ( n_paint_is_zoom_in( zoom ) ) { dot *= z; }


	return dot;
}

void
n_paint_frame_anim_on( void )
{

	if ( n_paint_frame_anim_timer == 0 ) { n_paint_frame_anim_timer = n_win_timer_id_get(); }
	n_win_timer_init( hwnd_main, n_paint_frame_anim_timer, 1 );

	n_paint_frame_anim_step = 0;

	n_paint_frame_anim_onoff = n_posix_true;

}

void
n_paint_frame_anim_off( void )
{

	n_win_timer_exit( hwnd_main, n_paint_frame_anim_timer );

	n_paint_frame_anim_onoff = n_posix_false;

}

n_posix_bool
n_paint_frame_is_hovered( int index )
{

	n_posix_bool ret = n_posix_false;


	n_type_gfx dot_full = n_paint_frame_anim_dot_size();
	n_type_gfx dot_half = dot_full / 2;

	n_type_gfx px,py; n_win_cursor_position_relative( hwnd_main, &px, &py );

	{
		n_type_gfx x = n_paint_frame_anim_ctl[ index ].x;
		n_type_gfx y = n_paint_frame_anim_ctl[ index ].y;

		n_paint_frame_anim_pos( &x, &y );

		if (
			( px >= ( x - dot_half ) )&&( px <= ( x + dot_half ) )
			&&
			( py >= ( y - dot_half ) )&&( py <= ( y + dot_half ) )
		)
		{
			ret = n_posix_true;
		}

	}


	return ret;
}

void
n_paint_frame_anim_proc( HWND hwnd, UINT msg, WPARAM wparam, LPARAM lparam )
{
//return;

	switch( msg ) {


	case WM_TIMER :

		// [!] : Win95 needs to check WPARAM is ID or not

		if ( wparam == 0 ) { break; }

		if ( wparam != n_paint_frame_anim_timer ) { break; }

		if (
			( N_PAINT_GRABBER_IS_DRAG_OK() )
			||
			( N_PAINT_GRABBER_IS_DRAGGING() )
			||
			( N_PAINT_GRABBER_IS_STRETCH_PROPORTIONAL() )
			||
			( N_PAINT_GRABBER_IS_STRETCH_TRANSFORM() )
		)
		{
			static u32 timer = 0;
			if ( n_game_timer( &timer, N_PAINT_FRAME_ANIM_INTERVAL ) )
			{
				n_paint_frame_anim_step++;

				n_paint_grabber_resync_auto();
			}
		}

	break;


	case WM_MOUSEMOVE :

		if ( n_paint_frame_anim_onoff )
		{

			if (
				( n_paint_frame_anim_lock == n_posix_false )
				&&
				( N_PAINT_GRABBER_IS_DRAG_OK() )
			)
			{
				n_win_message_post( hwnd, WM_TIMER, n_paint_frame_anim_timer, 0 );

				int i = 0;
				n_posix_loop
				{
					if ( n_paint_frame_is_hovered( i ) )
					{
						if ( n_win_is_input( VK_LBUTTON ) )
						{
							grabber = N_PAINT_GRABBER_RESELECT;
							break;
						}
					}

					i++;
					if ( i >= 4 ) { break; }
				}
			}

		}

	break;


	} // switch


	return;
}

void
n_paint_frame_anim_init
(
	n_type_gfx bitmap_sx, n_type_gfx bitmap_sy,
	n_type_gfx  frame_fx, n_type_gfx  frame_fy,
	n_type_gfx  frame_tx, n_type_gfx  frame_ty
)
{
//return;


	n_paint_frame_anim_path = n_memory_new( bitmap_sx * bitmap_sy * sizeof( POINT ) );


	// [!] : clockwise

	n_type_int i = 0;
	n_type_gfx x = frame_fx;
	n_type_gfx y = frame_fy;

	n_posix_loop
	{
		POINT p = { x, y };
		n_paint_frame_anim_path[ i ] = p; i++;

		x++;
		if ( x >= frame_tx ) { break; }
	}

	{
		POINT p = { x, y };
		n_paint_frame_anim_ctl[ 1 ] = p;
	}

	n_posix_loop
	{
		POINT p = { x, y };
		n_paint_frame_anim_path[ i ] = p; i++;

		y++;
		if ( y >= frame_ty ) { break; }
	}

	{
		POINT p = { x, y };
		n_paint_frame_anim_ctl[ 2 ] = p;
	}

	n_posix_loop
	{
		POINT p = { x, y };
		n_paint_frame_anim_path[ i ] = p; i++;

		x--;
		if ( x <= frame_fx ) { break; }
	}

	{
		POINT p = { x, y };
		n_paint_frame_anim_ctl[ 3 ] = p;
	}

	n_posix_loop
	{
		POINT p = { x, y };
		n_paint_frame_anim_path[ i ] = p; i++;

		y--;
		if ( y <= frame_fy ) { break; }
	}

	{
		POINT p = { x, y };
		n_paint_frame_anim_ctl[ 0 ] = p;
	}

	n_paint_frame_anim_count = i;


	return;
}

n_posix_bool
n_paint_frame_anim_detect( n_type_gfx x, n_type_gfx y, n_type_gfx zoom )
{
//return n_posix_false;
//return n_posix_true;

	n_posix_bool ret = n_posix_false; 


	if ( n_paint_frame_anim_path == NULL ) { return ret; }


	// [!] : animation will be anti-clockwise : because of macOS is so

	const n_type_int step = 6;

	n_type_int a = ( step - 1 ) - ( n_paint_frame_anim_step % step );

	n_type_int i = 0;
	n_posix_loop
	{//break;

		if ( ( n_paint_frame_anim_path[ i ].x == x )&&( n_paint_frame_anim_path[ i ].y == y ) )
		{
			n_type_int condition = ( i % step );

			if ( condition == a )
			{
				ret = n_posix_true;
				break;
			}
		}

		i++;
		if ( i >= n_paint_frame_anim_count ) { break; }
	}


	return ret;
}

void
n_paint_frame_anim_exit( n_bmp *bmp )
{
//return;

	if ( n_paint_frame_anim_path == NULL ) { return; }

	if (
		( N_PAINT_GRABBER_IS_DRAG_OK() )
		||
		( N_PAINT_GRABBER_IS_SELECTING() )
		||
		( N_PAINT_GRABBER_IS_DRAGGING() )
		||
		( N_PAINT_GRABBER_IS_STRETCH_PROPORTIONAL() )
		||
		( N_PAINT_GRABBER_IS_STRETCH_TRANSFORM() )
	)
	{

		const u32 color_border = n_bmp_rgb( 111,111,111 );
		const u32 color_accent = n_win_dwm_windowcolor();


		n_type_gfx gx,gy,gsx,gsy;
		n_paint_grabber_system_get( &gx,&gy, &gsx,&gsy, NULL,NULL );
		n_paint_zoom_bitmap2canvas( NULL,NULL, &gsx,&gsy );
		n_paint_frame_anim_pos( &gx, &gy );


		n_type_gfx z = n_paint_zoom_get( zoom );


		n_type_gfx dot_full = n_paint_frame_anim_dot_size();
		n_type_gfx dot_half = dot_full / 2;

		n_type_gfx contour  = n_posix_max_n_type_gfx( 1, z / 3 );


		n_bmp zoom_out_map;
		if ( n_paint_is_zoom_out( zoom ) ) 
		{
			n_bmp_carboncopy( bmp, &zoom_out_map );
			n_bmp_flush( &zoom_out_map, 0 );
		}


		int i = 0;

		n_type_gfx px = n_paint_frame_anim_path[ i ].x;
		n_type_gfx py = n_paint_frame_anim_path[ i ].y;

		n_paint_frame_anim_pos( &px, &py );

		i++;

		n_posix_loop
		{//break;

			n_type_gfx x = n_paint_frame_anim_path[ i ].x;
			n_type_gfx y = n_paint_frame_anim_path[ i ].y;

			n_type_gfx detect_x = x;
			n_type_gfx detect_y = y;

			n_paint_frame_anim_pos( &x, &y );

			if ( n_paint_is_zoom_out( zoom ) )
			{

				// [x] : process many times then border may disappear

				n_type_gfx zx = x / z * z;
				n_type_gfx zy = y / z * z;

				u32 c;
				n_bmp_ptr_get( &zoom_out_map, zx, zy, &c );
				if ( c == 0 )
				{
					n_bmp_ptr_get( bmp, zx, zy, &c );
					n_bmp_ptr_set( bmp, zx, zy, ~c );

					//n_bmp_ptr_set( bmp, zx, zy, color_border );

					c = 1;
					n_bmp_ptr_set( &zoom_out_map, zx, zy, c );
				}

			} else
			if ( n_paint_frame_anim_detect( detect_x, detect_y, z ) )
			{

				if ( py == y )
				{

					n_type_gfx zsx = z * 4;
					n_type_gfx zsy = z * 2;
					n_type_gfx oy;

					if ( px <= x ) { oy = zsy; } else { oy = 0; }

					if ( ( x + zsx ) < ( gx + gsx ) )
					{

						n_type_gfx o;
						n_type_gfx oo;

						o  = 0;
						oo = o * 2;

						n_bmp_roundrect_ratio( bmp, x+o,y+o-oy, zsx-oo,zsy-oo,  n_bmp_white, 100 );

						o  = contour;
						oo = o * 2;

						n_bmp_roundrect_ratio( bmp, x+o,y+o-oy, zsx-oo,zsy-oo, color_border, 100 );

					}

				} else
				if ( px == x )
				{

					n_type_gfx zsx = z * 2;
					n_type_gfx zsy = z * 4;
					n_type_gfx ox;

					if ( py >= y ) { ox = zsx; } else { ox = 0; }

					if ( ( y + zsy ) < ( gy + gsy ) )
					{

						n_type_gfx o;
						n_type_gfx oo;

						o  = 0;
						oo = o * 2;

						n_bmp_roundrect_ratio( bmp, x+o-ox,y+o, zsx-oo,zsy-oo,  n_bmp_white, 100 );

						o  = contour;
						oo = o * 2;

						n_bmp_roundrect_ratio( bmp, x+o-ox,y+o, zsx-oo,zsy-oo, color_border, 100 );

					}

				}

			} else
			if ( 1 == n_paint_zoom_get( zoom ) )
			{

				u32 c;
				n_bmp_ptr_get( bmp, x,y, &c );
				n_bmp_ptr_set( bmp, x,y, ~c );

			} else {

				// [!] : for debugging
				//n_bmp_box( bmp, x, y, z, z, color_border );

			}


			px = x;
			py = y;

			i++;
			if ( i >= n_paint_frame_anim_count ) { break; }
		}


		i = 0;
		n_posix_loop
		{//break;

			n_type_gfx x = n_paint_frame_anim_ctl[ i ].x;
			n_type_gfx y = n_paint_frame_anim_ctl[ i ].y;

			n_paint_frame_anim_pos( &x, &y );

			u32 color;
			if ( n_paint_frame_anim_lock )
			{
				color = color_border;
			} else {
				color = color_accent;
			}

			if ( 1 == n_paint_zoom_get( zoom ) ) { x++; y++; } // [Patch]

			n_bmp_circle
			(
				bmp,
				x - dot_half,
				y - dot_half,
				    dot_full,
				    dot_full,
				n_bmp_white
			);

			n_bmp_circle
			(
				bmp,
				x - dot_half + contour,
				y - dot_half + contour,
				    dot_full - ( contour * 2 ),
				    dot_full - ( contour * 2 ),
				color
			);

			i++;
			if ( i >= 4 ) { break; }
		}


		if ( n_paint_is_zoom_out( zoom ) ) 
		{
			n_bmp_free_fast( &zoom_out_map );
		}

	}


	n_memory_free( n_paint_frame_anim_path );
	n_paint_frame_anim_path = NULL;


	return;
}


