// Sample : Restore Window
// copyright (c) nonnon all rights reserved
// License : GPL http://www.gnu.org/copyleft/gpl.html


// [x] : Supported Windows Versions
//
//	9x    : not checked
//	NT4   : not checked
//	2000  : NG
//	XP    : NG
//	Vista : OK
//	7     : OK
//	8.1   : OK
//	10    : NG
//	11    : not checked




#include "../nonnon/project/define_unicode.c"




#include "../nonnon/win32/win.c"


#include "../nonnon/project/macro.c"




LRESULT CALLBACK
WndProc( HWND hwnd, UINT msg, WPARAM wparam, LPARAM lparam )
{

	static HWND hgui;

	static n_win w;
	static n_win w_prv;


	switch( msg ) {


	case WM_CREATE :

		n_win_init_literal( hwnd, "Tutorial", "MAIN_ICON", "" );

		n_win_gui_literal( hwnd, N_WIN_GUI_BUTTON, "Button", &hgui );


		n_win_style_new( hwnd, WS_OVERLAPPEDWINDOW );

		n_win_set( hwnd, &w, 256,256, N_WIN_SET_CENTERING | N_WIN_SET_CLIPPING );
		w_prv = w;


		// [x] : Win7 or earlier and Win10 : restore animation will start from zero co-ord


		// [x] : this is not perfect solution

		ShowWindowAsync( hwnd, SW_NORMAL );
		DefWindowProc( hwnd, msg, wparam, lparam );


		ShowWindowAsync( hwnd, SW_MAXIMIZE );
		w_prv.state = SIZE_MAXIMIZED;

	break;


	case WM_MOVE :

		if (
			( n_false == IsIconic( hwnd ) )
			&&
			( n_false == IsZoomed( hwnd ) )
		)
		{
			n_win_position( hwnd, &w_prv.posx, &w_prv.posy );
		}

	break;


	case WM_SIZE :
	{

		int state = (int) wparam;

		if ( state == SIZE_MINIMIZED )
		{
			//
		} else
		if ( state == SIZE_RESTORED )
		{
			if ( w_prv.state == SIZE_MAXIMIZED )
			{
				w.posx = w_prv.posx;
				w.posy = w_prv.posy;
				w.csx  = w_prv.csx;
				w.csy  = w_prv.csy;

				n_win_set( hwnd, &w, w.csx,w.csy, N_WIN_SET_NEEDPOS );
			} else {
				n_win_set( hwnd, &w, -1,-1, N_WIN_SET_CALCONLY );
			}

			w_prv = w;
		} else
		if ( state == SIZE_MAXIMIZED )
		{
			n_win_set( hwnd, &w, -1,-1, N_WIN_SET_CALCONLY );
		}

		n_type_gfx ctl; n_win_stdsize( hwnd, NULL, &ctl, NULL );

		n_type_gfx sx = 100;
		n_type_gfx sy = ctl;

		n_win_move( hgui, ( w.csx - sx ) / 2, ( w.csy - sy ) / 2, sx,sy, n_posix_true );

	}
	break;


	case WM_COMMAND :

		if ( (HWND) lparam == hgui )
		{
			n_posix_debug_literal( "%s", n_posix_literal( "Hello!" ) );
		}

	break;


	case WM_CLOSE :

		ShowWindow( hwnd, SW_HIDE );

		DestroyWindow( hwnd );

	break;

	case WM_DESTROY :

		PostQuitMessage( 0 );

	break;


	} // switch


	return DefWindowProc( hwnd, msg, wparam, lparam );
}

int WINAPI
WinMain( HINSTANCE hinst, HINSTANCE prv_hinst, LPSTR cmd, int show )
{
	return n_win_main( NULL, WndProc );
}


